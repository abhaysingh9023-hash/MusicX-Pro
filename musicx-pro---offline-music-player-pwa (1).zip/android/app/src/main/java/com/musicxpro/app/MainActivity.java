package com.musicxpro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
