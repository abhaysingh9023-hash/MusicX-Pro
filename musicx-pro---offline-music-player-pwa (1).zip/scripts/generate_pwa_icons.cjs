const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Brand-new MusicX Pro SVG Logo: Sleek Obsidian Hexagon-Disc + Neon Lime Play-Wave Emblem
const svgIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <radialGradient id="mxBg" cx="50%" cy="35%" r="65%">
      <stop offset="0%" stop-color="#1E2B0A" />
      <stop offset="55%" stop-color="#121410" />
      <stop offset="100%" stop-color="#0A0A0A" />
    </radialGradient>
    <linearGradient id="mxNeon" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#E2FF54" />
      <stop offset="50%" stop-color="#C6FF00" />
      <stop offset="100%" stop-color="#8CE600" />
    </linearGradient>
    <linearGradient id="mxRing" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#C6FF00" stop-opacity="0.15" />
      <stop offset="50%" stop-color="#C6FF00" stop-opacity="0.9" />
      <stop offset="100%" stop-color="#E2FF54" stop-opacity="0.3" />
    </linearGradient>
  </defs>

  <!-- Outer Dark Squircle Canvas -->
  <rect width="512" height="512" rx="116" fill="#0F0F0F" />
  <rect x="16" y="16" width="480" height="480" rx="104" fill="url(#mxBg)" stroke="#242B18" stroke-width="4" />

  <!-- Outer Acoustic Arc Ring -->
  <circle cx="256" cy="256" r="176" fill="none" stroke="url(#mxRing)" stroke-width="8" stroke-dasharray="180 28 70 28" stroke-linecap="round" />
  <circle cx="256" cy="256" r="146" fill="#11130F" stroke="#252B1B" stroke-width="3" />

  <!-- Left & Right Sound Equalizer Bars -->
  <rect x="116" y="216" width="16" height="80" rx="8" fill="#C6FF00" opacity="0.9" />
  <rect x="86" y="236" width="14" height="40" rx="7" fill="#C6FF00" opacity="0.55" />
  <rect x="380" y="216" width="16" height="80" rx="8" fill="#C6FF00" opacity="0.9" />
  <rect x="412" y="236" width="14" height="40" rx="7" fill="#C6FF00" opacity="0.55" />

  <!-- Stylized X-Prism + Play Triangle Emblem -->
  <path d="M198 168 L344 256 L198 344 Z" fill="url(#mxNeon)" />
  <!-- Geometric X-cut accent across the play emblem -->
  <path d="M180 182 L242 256 L180 330" fill="none" stroke="#0F0F0F" stroke-width="20" stroke-linecap="round" stroke-linejoin="round" />
  <path d="M180 182 L242 256 L180 330" fill="none" stroke="#E2FF54" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" />
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgIcon, 'utf8');

// Helper for signed distance to a line segment
function distToSegment(px, py, x1, y1, x2, y2) {
  const l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
  if (l2 === 0) return Math.hypot(px - x1, py - y1);
  let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * (x2 - x1)), py - (y1 + t * (y2 - y1)));
}

// Helper for point-in-triangle
function pointInTriangle(px, py, x1, y1, x2, y2, x3, y3) {
  const d1 = (px - x2) * (y1 - y2) - (x1 - x2) * (py - y2);
  const d2 = (px - x3) * (y2 - y3) - (x2 - x3) * (py - y3);
  const d3 = (px - x1) * (y3 - y1) - (x3 - x1) * (py - y1);
  const hasNeg = d1 < 0 || d2 < 0 || d3 < 0;
  const hasPos = d1 > 0 || d2 > 0 || d3 > 0;
  return !(hasNeg && hasPos);
}

// Render clean anti-aliased-like PNG matching the new Play-Wave X-Prism logo
function createPNG(width, height, isMaskable = false) {
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8);
  ihdr.writeUInt8(6, 9);
  ihdr.writeUInt8(0, 10);
  ihdr.writeUInt8(0, 11);
  ihdr.writeUInt8(0, 12);
  const ihdrChunk = makeChunk('IHDR', ihdr);

  const rawData = Buffer.alloc(height * (1 + width * 4));
  let offset = 0;

  const cx = width / 2;
  const cy = height / 2;
  // Scale down icon slightly inside maskable safe-zone (80%)
  const scale = (isMaskable ? 0.78 : 0.94) * (width / 512);

  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0;
    for (let x = 0; x < width; x++) {
      // Normalized coordinates in 512x512 space centered at 256, 256
      const nx = (x - cx) / scale + 256;
      const ny = (y - cy) / scale + 256;
      const dx = nx - 256;
      const dy = ny - 256;
      const dist = Math.hypot(dx, dy);

      // Base dark obsidian gradient
      let r = 15;
      let g = 15;
      let b = 15;
      const a = 255;

      // Radial glow in center
      if (dist < 230) {
        const glow = Math.max(0, 1 - dist / 230);
        r = Math.round(15 + glow * 15);
        g = Math.round(15 + glow * 28);
        b = Math.round(15 + glow * 4);
      }

      // Outer neon ring (r=176)
      if (Math.abs(dist - 176) < 4.5) {
        const angle = Math.atan2(dy, dx);
        if (Math.sin(angle * 2) > -0.55) {
          r = 198; g = 255; b = 0;
        } else {
          r = 50; g = 65; b = 22;
        }
      }

      // Inner dark ring border (r=146)
      if (Math.abs(dist - 146) < 2.2) {
        r = 37; g = 43; b = 27;
      }

      // Side Equalizer Bars
      const inLeftOuter = nx >= 86 && nx <= 100 && ny >= 236 && ny <= 276;
      const inLeftInner = nx >= 116 && nx <= 132 && ny >= 216 && ny <= 296;
      const inRightInner = nx >= 380 && nx <= 396 && ny >= 216 && ny <= 296;
      const inRightOuter = nx >= 412 && nx <= 426 && ny >= 236 && ny <= 276;

      if (inLeftInner || inRightInner) {
        r = 198; g = 255; b = 0;
      } else if (inLeftOuter || inRightOuter) {
        r = 128; g = 170; b = 12;
      }

      // Play Triangle (198,168) -> (344,256) -> (198,344)
      if (pointInTriangle(nx, ny, 198, 168, 344, 256, 198, 344)) {
        const t = (nx - 198) / 146;
        r = Math.round(220 - t * 35);
        g = 255;
        b = Math.round(70 - t * 70);
      }

      // Dark cutout + bright chevron X-wave on left edge of play triangle
      const seg1 = distToSegment(nx, ny, 180, 182, 242, 256);
      const seg2 = distToSegment(nx, ny, 242, 256, 180, 330);
      const minSeg = Math.min(seg1, seg2);
      if (minSeg < 10) {
        if (minSeg < 4) {
          r = 226; g = 255; b = 84;
        } else {
          r = 15; g = 15; b = 15;
        }
      }

      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressedData);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function makeChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const crc = crc32(chunk.subarray(4, 8 + len));
  chunk.writeInt32BE(crc, 8 + len);
  return chunk;
}

const crcTable = new Int32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return crc ^ -1;
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPNG(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPNG(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPNG(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPNG(180, 180, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), createPNG(64, 64, false));

// Sync Android launcher icons if Capacitor android/ directory is present
const androidResDir = path.resolve(__dirname, '../android/app/src/main/res');
if (fs.existsSync(androidResDir)) {
  const densities = [
    { dir: 'mipmap-mdpi', icon: 48, fg: 108 },
    { dir: 'mipmap-hdpi', icon: 72, fg: 162 },
    { dir: 'mipmap-xhdpi', icon: 96, fg: 216 },
    { dir: 'mipmap-xxhdpi', icon: 144, fg: 324 },
    { dir: 'mipmap-xxxhdpi', icon: 192, fg: 432 },
  ];
  for (const d of densities) {
    const targetDir = path.join(androidResDir, d.dir);
    if (fs.existsSync(targetDir)) {
      fs.writeFileSync(path.join(targetDir, 'ic_launcher.png'), createPNG(d.icon, d.icon, false));
      fs.writeFileSync(path.join(targetDir, 'ic_launcher_round.png'), createPNG(d.icon, d.icon, true));
      fs.writeFileSync(path.join(targetDir, 'ic_launcher_foreground.png'), createPNG(d.fg, d.fg, true));
    }
  }
  console.log('Android mipmap launcher icons updated!');
}

console.log('Updated MusicX Pro logo icons successfully generated in /public!');
