import React from 'react';

interface BrandLogoProps {
  size?: number;
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 40, className = '' }) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 rounded-2xl overflow-hidden shadow-lg shadow-[#C6FF00]/15 border border-[#C6FF00]/35 bg-[#0F0F0F] ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 512 512"
        className="w-full h-full"
        aria-label="MusicX Pro Logo"
      >
        <defs>
          <radialGradient id="brandBg" cx="50%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#1E2B0A" />
            <stop offset="60%" stopColor="#121410" />
            <stop offset="100%" stopColor="#0A0A0A" />
          </radialGradient>
          <linearGradient id="brandNeon" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E2FF54" />
            <stop offset="50%" stopColor="#C6FF00" />
            <stop offset="100%" stopColor="#8CE600" />
          </linearGradient>
          <linearGradient id="brandRing" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#C6FF00" stopOpacity="0.2" />
            <stop offset="50%" stopColor="#C6FF00" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#E2FF54" stopOpacity="0.35" />
          </linearGradient>
        </defs>

        <rect width="512" height="512" fill="url(#brandBg)" />

        <circle
          cx="256"
          cy="256"
          r="176"
          fill="none"
          stroke="url(#brandRing)"
          strokeWidth="12"
          strokeDasharray="180 28 70 28"
          strokeLinecap="round"
        />
        <circle
          cx="256"
          cy="256"
          r="146"
          fill="#11130F"
          stroke="#262E1A"
          strokeWidth="4"
        />

        <rect x="112" y="212" width="18" height="88" rx="9" fill="#C6FF00" opacity="0.9" />
        <rect x="80" y="234" width="16" height="44" rx="8" fill="#C6FF00" opacity="0.55" />
        <rect x="382" y="212" width="18" height="88" rx="9" fill="#C6FF00" opacity="0.9" />
        <rect x="416" y="234" width="16" height="44" rx="8" fill="#C6FF00" opacity="0.55" />

        <path d="M198 166 L346 256 L198 346 Z" fill="url(#brandNeon)" />
        <path
          d="M178 180 L242 256 L178 332"
          fill="none"
          stroke="#0F0F0F"
          strokeWidth="22"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M178 180 L242 256 L178 332"
          fill="none"
          stroke="#E2FF54"
          strokeWidth="10"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};
