import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, X, Heart, Play, Music, ArrowUpDown, ListPlus } from 'lucide-react';
import { Song, SortOption } from '../types/music';
import { BrandLogo } from './BrandLogo';

interface SearchViewProps {
  songs: Song[];
  currentSongId: string | null;
  isPlaying: boolean;
  onSelectSong: (song: Song) => void;
  onToggleFavorite: (songId: string) => void;
  onAddToPlaylist: (song: Song) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  songs,
  currentSongId,
  isPlaying,
  onSelectSong,
  onToggleFavorite,
  onAddToPlaylist,
}) => {
  const [query, setQuery] = useState('');
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('title-asc');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const results = useMemo(() => {
    let list = [...songs];
    if (query.trim()) {
      const q = query.toLowerCase().trim();
      list = list.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.artist.toLowerCase().includes(q) ||
          (s.album && s.album.toLowerCase().includes(q))
      );
    }
    if (favoritesOnly) {
      list = list.filter((s) => s.isFavorite);
    }
    list.sort((a, b) => {
      if (sortBy === 'recent') return b.dateAdded - a.dateAdded;
      if (sortBy === 'title-asc') return a.title.localeCompare(b.title);
      if (sortBy === 'title-desc') return b.title.localeCompare(a.title);
      if (sortBy === 'artist-asc') return a.artist.localeCompare(b.artist);
      if (sortBy === 'duration-desc') return b.duration - a.duration;
      return 0;
    });
    return list;
  }, [songs, query, favoritesOnly, sortBy]);

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-5">
      {/* Header with Brand Logo */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <BrandLogo size={40} />
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Search <span className="text-[#C6FF00]">Library</span>
            </h1>
            <p className="text-xs text-slate-400">Find tracks, artists & albums offline</p>
          </div>
        </div>
      </div>

      {/* Prominent Search Box */}
      <div className="relative">
        <Search className="w-5 h-5 text-[#C6FF00] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type song title, artist, or album..."
          className="w-full pl-12 pr-12 py-3.5 rounded-2xl bg-[#161616] border border-[#2C2C2C] text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#C6FF00] shadow-lg transition"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1.5 rounded-xl bg-[#242424] text-slate-300 hover:text-white transition cursor-pointer"
            aria-label="Clear search"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Quick Filters */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <button
          onClick={() => setFavoritesOnly(!favoritesOnly)}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-semibold transition cursor-pointer ${
            favoritesOnly
              ? 'bg-rose-500/15 border-rose-500 text-rose-400'
              : 'bg-[#161616] border-[#262626] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Heart className="w-3.5 h-3.5" fill={favoritesOnly ? 'currentColor' : 'none'} />
          <span>Favorites Only</span>
        </button>

        <div className="relative flex items-center">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortOption)}
            className="pl-8 pr-6 py-2 rounded-xl bg-[#161616] border border-[#262626] text-xs font-semibold text-slate-200 focus:outline-none focus:border-[#C6FF00] cursor-pointer appearance-none"
          >
            <option value="title-asc">Title (A - Z)</option>
            <option value="title-desc">Title (Z - A)</option>
            <option value="artist-asc">Artist (A - Z)</option>
            <option value="recent">Recently Added</option>
            <option value="duration-desc">Duration (Longest)</option>
          </select>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>{results.length} {results.length === 1 ? 'result' : 'results'}</span>
        {query && <span>Matching &ldquo;{query}&rdquo;</span>}
      </div>

      {/* Results List */}
      {results.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#141414] border border-[#222] text-center space-y-2.5">
          <Music className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-white">No tracks found</h3>
          <p className="text-xs text-slate-400">
            Try another keyword or clear your active filters.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-[#1F1F1F] rounded-3xl bg-[#141414] border border-[#242424] overflow-hidden">
          {results.map((song) => {
            const isCurrent = currentSongId === song.id;
            return (
              <div
                key={song.id}
                onClick={() => onSelectSong(song)}
                className={`flex items-center justify-between p-3.5 transition-all cursor-pointer group ${
                  isCurrent ? 'bg-[#C6FF00]/10 text-white' : 'hover:bg-[#1A1A1A]'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="relative w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-[#282828]">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play className="w-4 h-4 text-[#C6FF00] fill-[#C6FF00]" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div
                      className={`text-sm font-semibold truncate ${
                        isCurrent && isPlaying ? 'text-[#C6FF00]' : 'text-white group-hover:text-[#C6FF00]'
                      }`}
                    >
                      {song.title}
                    </div>
                    <div className="text-xs text-slate-400 truncate mt-0.5">
                      {song.artist} {song.album ? `· ${song.album}` : ''}
                    </div>
                  </div>
                </div>

                <div
                  className="flex items-center gap-2 shrink-0"
                  onClick={(e) => e.stopPropagation()}
                >
                  <span className="text-xs font-mono text-slate-400 tabular-nums">
                    {formatTime(song.duration)}
                  </span>
                  <button
                    onClick={() => onToggleFavorite(song.id)}
                    className={`p-2 rounded-xl transition cursor-pointer ${
                      song.isFavorite
                        ? 'text-rose-500 hover:bg-rose-500/10'
                        : 'text-slate-500 hover:text-white hover:bg-[#242424]'
                    }`}
                    title="Favorite"
                  >
                    <Heart className="w-4 h-4" fill={song.isFavorite ? 'currentColor' : 'none'} />
                  </button>
                  <button
                    onClick={() => onAddToPlaylist(song)}
                    className="p-2 text-slate-400 hover:text-[#C6FF00] hover:bg-[#242424] rounded-xl transition cursor-pointer"
                    title="Add to Playlist"
                  >
                    <ListPlus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
