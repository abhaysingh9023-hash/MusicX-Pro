const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate SVG icon
const svgIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <radialGradient id="bgGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#1A2810" />
      <stop offset="100%" stop-color="#0F0F0F" />
    </radialGradient>
    <linearGradient id="neonGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#D9FF38" />
      <stop offset="100%" stop-color="#99E600" />
    </linearGradient>
    <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur" />
      <feMerge>
        <feMergeNode in="blur" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
  </defs>
  <!-- Background -->
  <rect width="512" height="512" rx="112" fill="#0F0F0F" />
  <circle cx="256" cy="256" r="230" fill="url(#bgGlow)" stroke="#222" stroke-width="4" />
  
  <!-- Outer vinyl grooves -->
  <circle cx="256" cy="256" r="180" fill="none" stroke="#262626" stroke-width="3" />
  <circle cx="256" cy="256" r="150" fill="none" stroke="#202020" stroke-width="2" />
  
  <!-- Equalizer waves ring -->
  <circle cx="256" cy="256" r="110" fill="#141414" stroke="#C6FF00" stroke-width="4" filter="url(#neonGlow)" />
  
  <!-- Stylized M & Soundwave / Play icon in Lime Green -->
  <path d="M190 170 L216 170 L256 240 L296 170 L322 170 L322 342 L288 342 L288 238 L256 295 L224 238 L224 342 L190 342 Z" fill="url(#neonGrad)" filter="url(#neonGlow)" />
  
  <!-- Dynamic Audio Bar Accents -->
  <rect x="150" y="230" width="12" height="52" rx="6" fill="#C6FF00" opacity="0.85" />
  <rect x="126" y="250" width="12" height="32" rx="6" fill="#C6FF00" opacity="0.6" />
  <rect x="350" y="230" width="12" height="52" rx="6" fill="#C6FF00" opacity="0.85" />
  <rect x="374" y="250" width="12" height="32" rx="6" fill="#C6FF00" opacity="0.6" />
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgIcon, 'utf8');

// Function to write an uncompressed/deflated raw RGBA PNG
function createPNG(width, height, isMaskable = false) {
  // Simple PNG encoder
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  
  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // bit depth 8
  ihdr.writeUInt8(6, 9); // color type 6: RGBA
  ihdr.writeUInt8(0, 10); // compression
  ihdr.writeUInt8(0, 11); // filter
  ihdr.writeUInt8(0, 12); // interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);

  // Raw image data: height rows, each row has 1 filter byte + width * 4 bytes RGBA
  const rawData = Buffer.alloc(height * (1 + width * 4));
  let offset = 0;

  const centerX = width / 2;
  const centerY = height / 2;
  const radius = width * 0.45;
  const innerRadius = width * 0.22;

  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter type None
    for (let x = 0; x < width; x++) {
      const dx = x - centerX;
      const dy = y - centerY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background color: #0F0F0F (15, 15, 15, 255)
      let r = 15;
      let g = 15;
      let b = 15;
      let a = 255;

      // Neon lime color: #C6FF00 (198, 255, 0)
      if (dist < radius && dist > innerRadius) {
        // subtle vinyl groove
        const groove = Math.sin(dist * 0.25);
        if (groove > 0.6) {
          r = 30; g = 38; b = 25;
        }
      }

      // Center neon glow ring
      if (Math.abs(dist - innerRadius) < (width * 0.025)) {
        r = 198; g = 255; b = 0;
      }

      // Draw stylized 'M' in center
      const nx = (x - centerX) / (width * 0.25);
      const ny = (y - centerY) / (height * 0.25);

      if (ny >= -0.7 && ny <= 0.7 && Math.abs(nx) <= 0.8) {
        const leftStem = Math.abs(nx - (-0.6)) < 0.14;
        const rightStem = Math.abs(nx - 0.6) < 0.14;
        const leftDiag = Math.abs((ny - 0.2) - (nx * 1.2 + 0.3)) < 0.16 && nx <= 0 && ny <= 0.4;
        const rightDiag = Math.abs((ny - 0.2) - (-nx * 1.2 + 0.3)) < 0.16 && nx >= 0 && ny <= 0.4;

        if (leftStem || rightStem || leftDiag || rightDiag) {
          r = 198; g = 255; b = 0; // Lime
        }
      }

      // Write RGBA
      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressedData);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function makeChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  
  // Calculate CRC
  const crc = crc32(chunk.subarray(4, 8 + len));
  chunk.writeInt32BE(crc, 8 + len);
  return chunk;
}

// Standard CRC32 table
const crcTable = new Int32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return crc ^ -1;
}

// Generate PWA Icons
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPNG(192, 192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPNG(512, 512));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPNG(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPNG(180, 180));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), createPNG(64, 64));

console.log('PWA icons successfully generated in /public!');
