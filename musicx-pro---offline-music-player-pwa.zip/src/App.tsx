import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Song, Playlist, RepeatMode, SleepTimerState } from './types/music';
import {
  getAllSongs,
  getAllPlaylists,
  getStorageStats,
  seedInitialLibraryIfEmpty,
  getSongAudioBlob,
  getAudioObjectUrl,
  toggleSongFavoriteInDB,
  deleteSongFromDB,
  clearAllSongsFromDB,
  savePlaylistToDB,
  renamePlaylistInDB,
  deletePlaylistFromDB,
  addSongToPlaylistInDB,
  removeSongFromPlaylistInDB,
} from './services/db';
import { audioEngine } from './services/audioEngine';
import { importAudioFiles } from './utils/fileImporter';
import { LibraryView } from './components/LibraryView';
import { PlaylistsView } from './components/PlaylistsView';
import { StorageView } from './components/StorageView';
import { MiniPlayer } from './components/MiniPlayer';
import { FullScreenPlayer } from './components/FullScreenPlayer';
import { BottomNav, NavTab } from './components/BottomNav';
import { AddToPlaylistModal } from './components/AddToPlaylistModal';

export default function App() {
  const [songs, setSongs] = useState<Song[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [activeTab, setActiveTab] = useState<NavTab>('library');
  const [isFullScreenOpen, setIsFullScreenOpen] = useState(false);
  const [storageBytes, setStorageBytes] = useState(0);
  const [songToAddToPlaylist, setSongToAddToPlaylist] = useState<Song | null>(null);
  const [isImporting, setIsImporting] = useState(false);

  const [sleepTimer, setSleepTimer] = useState<SleepTimerState>({
    totalMinutes: 0,
    remainingSeconds: 0,
    isActive: false,
    targetTimestamp: null,
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  // Load database on initial mount
  const refreshLibrary = useCallback(async () => {
    try {
      await seedInitialLibraryIfEmpty();
      const [fetchedSongs, fetchedPlaylists, stats] = await Promise.all([
        getAllSongs(),
        getAllPlaylists(),
        getStorageStats(),
      ]);

      setSongs(fetchedSongs);
      setPlaylists(fetchedPlaylists);
      setStorageBytes(stats.totalBytes);

      // Auto-select first song if none selected
      if (!currentSong && fetchedSongs.length > 0) {
        setCurrentSong(fetchedSongs[0]);
      }
    } catch (e) {
      console.error('Error loading offline library:', e);
    }
  }, [currentSong]);

  useEffect(() => {
    refreshLibrary();
  }, [refreshLibrary]);

  // Audio element listeners
  useEffect(() => {
    const audio = audioEngine.getAudioElement();

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleDurationChange = () => {
      if (Number.isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    const handleEnded = () => {
      if (repeatMode === 'one') {
        audioEngine.seek(0);
        audioEngine.play();
      } else {
        handleNextTrack();
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('ended', handleEnded);
    };
  });

  // Play a specific song
  const playSong = async (song: Song, autoPlay = true) => {
    try {
      setCurrentSong(song);
      const blob = await getSongAudioBlob(song.id);
      if (!blob) {
        console.warn('Audio blob not found in IndexedDB for song', song.id);
        return;
      }
      const url = getAudioObjectUrl(song.id, blob);
      audioEngine.setSource(url);
      setDuration(song.duration);

      if (autoPlay) {
        await audioEngine.play();
        setIsPlaying(true);
      }
    } catch (e) {
      console.error('Error playing track:', e);
    }
  };

  const handleTogglePlay = async () => {
    if (!currentSong && songs.length > 0) {
      await playSong(songs[0], true);
      return;
    }

    if (isPlaying) {
      audioEngine.pause();
      setIsPlaying(false);
    } else {
      // If no src set yet
      const audio = audioEngine.getAudioElement();
      if (!audio.src && currentSong) {
        await playSong(currentSong, true);
      } else {
        await audioEngine.play();
        setIsPlaying(true);
      }
    }
  };

  const handleNextTrack = useCallback(() => {
    if (songs.length === 0) return;

    if (isShuffle) {
      const remaining = songs.filter((s) => s.id !== currentSong?.id);
      const nextSong = remaining.length > 0
        ? remaining[Math.floor(Math.random() * remaining.length)]
        : songs[0];
      playSong(nextSong, true);
      return;
    }

    const currentIndex = songs.findIndex((s) => s.id === currentSong?.id);
    if (currentIndex === -1 || currentIndex === songs.length - 1) {
      if (repeatMode === 'off') {
        audioEngine.pause();
        setIsPlaying(false);
        return;
      }
      playSong(songs[0], true);
    } else {
      playSong(songs[currentIndex + 1], true);
    }
  }, [songs, currentSong, isShuffle, repeatMode]);

  const handlePrevTrack = () => {
    if (songs.length === 0) return;

    // If more than 3 seconds in, rewind to beginning first
    if (currentTime > 3) {
      audioEngine.seek(0);
      return;
    }

    const currentIndex = songs.findIndex((s) => s.id === currentSong?.id);
    if (currentIndex <= 0) {
      playSong(songs[songs.length - 1], true);
    } else {
      playSong(songs[currentIndex - 1], true);
    }
  };

  const handleShuffleAll = () => {
    if (songs.length === 0) return;
    setIsShuffle(true);
    const randomIndex = Math.floor(Math.random() * songs.length);
    playSong(songs[randomIndex], true);
  };

  const handleSeek = (time: number) => {
    setCurrentTime(time);
    audioEngine.seek(time);
  };

  const handleSkipSeconds = (delta: number) => {
    audioEngine.skipSeconds(delta);
    setCurrentTime(audioEngine.getCurrentTime());
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    audioEngine.setVolume(vol);
  };

  const handleToggleRepeat = () => {
    const modes: RepeatMode[] = ['off', 'all', 'one'];
    const nextIdx = (modes.indexOf(repeatMode) + 1) % modes.length;
    setRepeatMode(modes[nextIdx]);
  };

  const handleToggleFavorite = async (songId: string) => {
    try {
      const isFav = await toggleSongFavoriteInDB(songId);
      setSongs((prev) =>
        prev.map((s) => (s.id === songId ? { ...s, isFavorite: isFav } : s))
      );
      if (currentSong?.id === songId) {
        setCurrentSong((prev) => (prev ? { ...prev, isFavorite: isFav } : null));
      }
    } catch (e) {
      console.error('Failed to toggle favorite:', e);
    }
  };

  const handleDeleteSong = async (songId: string) => {
    try {
      await deleteSongFromDB(songId);
      setSongs((prev) => prev.filter((s) => s.id !== songId));
      if (currentSong?.id === songId) {
        const nextSong = songs.find((s) => s.id !== songId) || null;
        if (nextSong) {
          playSong(nextSong, isPlaying);
        } else {
          audioEngine.pause();
          setCurrentSong(null);
          setIsPlaying(false);
        }
      }
      const stats = await getStorageStats();
      setStorageBytes(stats.totalBytes);
      setPlaylists(await getAllPlaylists());
    } catch (e) {
      console.error('Failed to delete song:', e);
    }
  };

  const handleClearLibrary = async () => {
    try {
      audioEngine.pause();
      setIsPlaying(false);
      setCurrentSong(null);
      await clearAllSongsFromDB();
      setSongs([]);
      setPlaylists(await getAllPlaylists());
      setStorageBytes(0);
    } catch (e) {
      console.error('Failed to clear library:', e);
    }
  };

  // Playlists Handlers
  const handleCreatePlaylist = async (name: string): Promise<Playlist> => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      songIds: [],
      dateCreated: Date.now(),
    };
    await savePlaylistToDB(newPl);
    setPlaylists((prev) => [...prev, newPl]);
    return newPl;
  };

  const handleRenamePlaylist = async (id: string, name: string) => {
    await renamePlaylistInDB(id, name);
    setPlaylists((prev) =>
      prev.map((p) => (p.id === id ? { ...p, name } : p))
    );
  };

  const handleDeletePlaylist = async (id: string) => {
    await deletePlaylistFromDB(id);
    setPlaylists((prev) => prev.filter((p) => p.id !== id));
  };

  const handleAddSongToPlaylist = async (playlistId: string, songId: string) => {
    await addSongToPlaylistInDB(playlistId, songId);
    setPlaylists((prev) =>
      prev.map((p) =>
        p.id === playlistId && !p.songIds.includes(songId)
          ? { ...p, songIds: [...p.songIds, songId] }
          : p
      )
    );
  };

  const handleRemoveSongFromPlaylist = async (playlistId: string, songId: string) => {
    await removeSongFromPlaylistInDB(playlistId, songId);
    setPlaylists((prev) =>
      prev.map((p) =>
        p.id === playlistId
          ? { ...p, songIds: p.songIds.filter((id) => id !== songId) }
          : p
      )
    );
  };

  const handlePlayPlaylist = (playlist: Playlist, shuffle = false) => {
    const plSongs = playlist.songIds
      .map((id) => songs.find((s) => s.id === id))
      .filter((s): s is Song => Boolean(s));

    if (plSongs.length === 0) return;

    setIsShuffle(shuffle);
    const startTrack = shuffle
      ? plSongs[Math.floor(Math.random() * plSongs.length)]
      : plSongs[0];
    playSong(startTrack, true);
  };

  // File Import Handlers
  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    setIsImporting(true);
    try {
      const imported = await importAudioFiles(e.target.files);
      if (imported.length > 0) {
        await refreshLibrary();
        // Play the first newly imported song
        const firstSong = songs.find((s) => s.id === imported[0].id) || imported[0];
        playSong(firstSong, true);
      }
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (folderInputRef.current) folderInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-slate-100 flex flex-col font-sans selection:bg-[#C6FF00] selection:text-black">
      {/* Hidden File Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="audio/*,.mp3,.wav,.aac,.m4a,.flac,.ogg"
        onChange={handleFilesSelected}
        className="hidden"
      />
      <input
        ref={folderInputRef}
        type="file"
        // @ts-expect-error webkitdirectory is standard in Chromium/Firefox
        webkitdirectory=""
        directory=""
        multiple
        onChange={handleFilesSelected}
        className="hidden"
      />

      {/* Main Viewport Container */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 pt-5 pb-44 md:pb-40">
        {isImporting && (
          <div className="mb-4 p-3.5 rounded-2xl bg-[#C6FF00]/10 border border-[#C6FF00]/30 text-xs text-[#C6FF00] font-semibold flex items-center justify-between animate-pulse">
            <span>Reading audio metadata and saving tracks into offline IndexedDB...</span>
            <span className="w-2 h-2 rounded-full bg-[#C6FF00]" />
          </div>
        )}

        {activeTab === 'library' && (
          <LibraryView
            songs={songs}
            currentSong={currentSong}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            onSelectSong={(song) => playSong(song, true)}
            onTogglePlay={handleTogglePlay}
            onNext={handleNextTrack}
            onPrev={handlePrevTrack}
            onSeek={handleSeek}
            onShuffleAll={handleShuffleAll}
            onToggleFavorite={handleToggleFavorite}
            onDeleteSong={handleDeleteSong}
            onAddToPlaylist={(song) => setSongToAddToPlaylist(song)}
            onAddFilesClick={() => fileInputRef.current?.click()}
            onAddFolderClick={() => folderInputRef.current?.click()}
            onOpenFullScreen={() => setIsFullScreenOpen(true)}
          />
        )}

        {activeTab === 'playlists' && (
          <PlaylistsView
            playlists={playlists}
            songs={songs}
            currentSongId={currentSong?.id || null}
            isPlaying={isPlaying}
            onCreatePlaylist={handleCreatePlaylist}
            onRenamePlaylist={handleRenamePlaylist}
            onDeletePlaylist={handleDeletePlaylist}
            onRemoveSongFromPlaylist={handleRemoveSongFromPlaylist}
            onAddSongToPlaylist={handleAddSongToPlaylist}
            onPlayPlaylist={handlePlayPlaylist}
            onSelectSong={(song) => playSong(song, true)}
          />
        )}

        {activeTab === 'storage' && (
          <StorageView
            songs={songs}
            playlistCount={playlists.length}
            totalBytes={storageBytes}
            onDeleteSong={handleDeleteSong}
            onClearLibrary={handleClearLibrary}
            onAddFilesClick={() => fileInputRef.current?.click()}
            onAddFolderClick={() => folderInputRef.current?.click()}
          />
        )}
      </main>

      {/* Floating Mini-Player (Zero UI overlap above bottom nav) */}
      {!isFullScreenOpen && (
        <MiniPlayer
          currentSong={currentSong}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          onTogglePlay={(e) => {
            e.stopPropagation();
            handleTogglePlay();
          }}
          onNext={(e) => {
            e.stopPropagation();
            handleNextTrack();
          }}
          onPrev={(e) => {
            e.stopPropagation();
            handlePrevTrack();
          }}
          onToggleFavorite={(e, id) => {
            e.stopPropagation();
            handleToggleFavorite(id);
          }}
          onOpenFullScreen={() => setIsFullScreenOpen(true)}
        />
      )}

      {/* Fixed Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        songCount={songs.length}
        playlistCount={playlists.length}
      />

      {/* Full-Screen Player Modal */}
      <FullScreenPlayer
        isOpen={isFullScreenOpen}
        onClose={() => setIsFullScreenOpen(false)}
        currentSong={currentSong}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        volume={volume}
        isShuffle={isShuffle}
        repeatMode={repeatMode}
        sleepTimer={sleepTimer}
        setSleepTimer={setSleepTimer}
        onTogglePlay={handleTogglePlay}
        onNext={handleNextTrack}
        onPrev={handlePrevTrack}
        onSeek={handleSeek}
        onSkipSeconds={handleSkipSeconds}
        onVolumeChange={handleVolumeChange}
        onToggleShuffle={() => setIsShuffle(!isShuffle)}
        onToggleRepeat={handleToggleRepeat}
        onToggleFavorite={handleToggleFavorite}
        onAddToPlaylist={(song) => setSongToAddToPlaylist(song)}
      />

      {/* Add To Playlist Modal */}
      <AddToPlaylistModal
        isOpen={Boolean(songToAddToPlaylist)}
        onClose={() => setSongToAddToPlaylist(null)}
        song={songToAddToPlaylist}
        playlists={playlists}
        onCreatePlaylist={handleCreatePlaylist}
        onAddSongToPlaylist={handleAddSongToPlaylist}
      />
    </div>
  );
}
