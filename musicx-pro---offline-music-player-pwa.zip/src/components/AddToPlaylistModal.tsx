import React, { useState } from 'react';
import { X, Plus, Check, ListMusic } from 'lucide-react';
import { Song, Playlist } from '../types/music';

interface AddToPlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  song: Song | null;
  playlists: Playlist[];
  onCreatePlaylist: (name: string) => Promise<Playlist>;
  onAddSongToPlaylist: (playlistId: string, songId: string) => Promise<void>;
}

export const AddToPlaylistModal: React.FC<AddToPlaylistModalProps> = ({
  isOpen,
  onClose,
  song,
  playlists,
  onCreatePlaylist,
  onAddSongToPlaylist,
}) => {
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [addedPlaylists, setAddedPlaylists] = useState<string[]>([]);

  if (!isOpen || !song) return null;

  const handleAddToPlaylist = async (playlistId: string) => {
    await onAddSongToPlaylist(playlistId, song.id);
    setAddedPlaylists((prev) => [...prev, playlistId]);
    setTimeout(() => {
      onClose();
    }, 600);
  };

  const handleCreateAndAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    const pl = await onCreatePlaylist(newPlaylistName.trim());
    await onAddSongToPlaylist(pl.id, song.id);
    setNewPlaylistName('');
    setIsCreating(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-[#141414] border border-[#282828] p-6 shadow-2xl text-slate-100 flex flex-col gap-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Add to Playlist</h2>
            <p className="text-xs text-slate-400 truncate max-w-[240px]">
              "{song.title}"
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-[#202020] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Existing Playlists */}
        <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
          {playlists.length === 0 ? (
            <div className="p-4 rounded-2xl bg-[#1A1A1A] text-center text-xs text-slate-400">
              No playlists created yet. Create your first one below!
            </div>
          ) : (
            playlists.map((pl) => {
              const alreadyIn = pl.songIds.includes(song.id) || addedPlaylists.includes(pl.id);
              return (
                <button
                  key={pl.id}
                  onClick={() => handleAddToPlaylist(pl.id)}
                  disabled={alreadyIn}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all text-sm font-medium ${
                    alreadyIn
                      ? 'bg-[#C6FF00]/10 border-[#C6FF00]/40 text-[#C6FF00] cursor-default'
                      : 'bg-[#181818] border-[#262626] text-slate-200 hover:bg-[#202020] hover:text-white cursor-pointer'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#222] flex items-center justify-center text-slate-400">
                      <ListMusic className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold text-white">{pl.name}</div>
                      <div className="text-[11px] text-slate-400">
                        {pl.songIds.length} {pl.songIds.length === 1 ? 'song' : 'songs'}
                      </div>
                    </div>
                  </div>

                  {alreadyIn ? (
                    <span className="flex items-center gap-1 text-xs text-[#C6FF00] font-semibold">
                      <Check className="w-4 h-4" /> Added
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400 group-hover:text-white">+ Add</span>
                  )}
                </button>
              );
            })
          )}
        </div>

        {/* Create new playlist form */}
        {isCreating ? (
          <form onSubmit={handleCreateAndAdd} className="space-y-2 pt-2 border-t border-[#222]">
            <input
              type="text"
              placeholder="Playlist name..."
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              autoFocus
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#1A1A1A] border border-[#333] text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#C6FF00]"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="flex-1 py-2 rounded-xl bg-[#222] text-xs font-semibold text-slate-300 hover:bg-[#282828]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-[#C6FF00] text-xs font-bold text-black hover:brightness-110"
              >
                Create & Add
              </button>
            </div>
          </form>
        ) : (
          <button
            onClick={() => setIsCreating(true)}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#1E1E1E] border border-dashed border-[#333] text-slate-300 hover:text-[#C6FF00] hover:border-[#C6FF00]/50 transition text-xs font-bold"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Playlist</span>
          </button>
        )}
      </div>
    </div>
  );
};
