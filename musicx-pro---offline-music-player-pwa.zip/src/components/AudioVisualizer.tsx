import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../services/audioEngine';

interface AudioVisualizerProps {
  isPlaying: boolean;
  barCount?: number;
  height?: number;
  className?: string;
  variant?: 'canvas' | 'bars';
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isPlaying,
  barCount = 32,
  height = 80,
  className = '',
  variant = 'canvas',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    if (variant !== 'canvas') return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const width = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, width, h);

      const freqData = audioEngine.getFrequencyData();
      const count = Math.min(barCount, freqData.length);
      const barSpacing = 4;
      const totalSpacing = (count - 1) * barSpacing;
      const barWidth = Math.max(3, (width - totalSpacing) / count);

      for (let i = 0; i < count; i++) {
        let val = freqData[i] || 0;

        // If not playing, draw an attractive idle waveform pulse
        if (!isPlaying) {
          const t = Date.now() * 0.003;
          val = Math.max(12, Math.sin(t + i * 0.25) * 16 + 24);
        } else {
          // Boost higher frequencies visually since human ear needs less high energy
          val = Math.min(255, val * (1 + (i / count) * 0.6));
        }

        const barHeight = Math.max(4, (val / 255) * (h * 0.88));
        const x = i * (barWidth + barSpacing);
        const y = h - barHeight;

        // Draw neon lime bar with gradient
        const gradient = ctx.createLinearGradient(0, y, 0, h);
        gradient.addColorStop(0, '#D9FF38');
        gradient.addColorStop(0.6, '#C6FF00');
        gradient.addColorStop(1, 'rgba(198, 255, 0, 0.25)');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        // Rounded top
        ctx.roundRect(x, y, barWidth, barHeight, [3, 3, 1, 1]);
        ctx.fill();

        // Neon Glow cap on top
        if (isPlaying && val > 40) {
          ctx.fillStyle = '#FFFFFF';
          ctx.shadowColor = '#C6FF00';
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, 3, [2, 2, 0, 0]);
          ctx.fill();
          ctx.shadowBlur = 0; // reset
        }
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [isPlaying, barCount, variant]);

  if (variant === 'bars') {
    return (
      <div className={`flex items-end gap-1 ${className}`} style={{ height: `${height}px` }}>
        {Array.from({ length: 4 }).map((_, i) => (
          <span
            key={i}
            className={`w-1 rounded-full bg-[#C6FF00] ${
              isPlaying ? 'animate-bounce' : 'h-1.5 opacity-40'
            }`}
            style={{
              height: isPlaying ? `${Math.floor(height * (0.35 + (i % 3) * 0.25))}px` : '4px',
              animationDelay: `${i * 0.15}s`,
              animationDuration: '0.8s',
            }}
          />
        ))}
      </div>
    );
  }

  return (
    <div className={`w-full overflow-hidden ${className}`}>
      <canvas
        ref={canvasRef}
        width={480}
        height={height}
        className="w-full h-full block"
      />
    </div>
  );
};
