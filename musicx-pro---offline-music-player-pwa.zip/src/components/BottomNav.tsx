import React from 'react';
import { Music, ListMusic, HardDrive } from 'lucide-react';

export type NavTab = 'library' | 'playlists' | 'storage';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  songCount: number;
  playlistCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  songCount,
  playlistCount,
}) => {
  const tabs = [
    {
      id: 'library' as NavTab,
      label: 'Library',
      icon: Music,
      badge: songCount > 0 ? songCount : undefined,
    },
    {
      id: 'playlists' as NavTab,
      label: 'Playlists',
      icon: ListMusic,
      badge: playlistCount > 0 ? playlistCount : undefined,
    },
    {
      id: 'storage' as NavTab,
      label: 'Storage & Setup',
      icon: HardDrive,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-[#101010]/95 backdrop-blur-2xl border-t border-[#222] z-40 px-4 flex items-center justify-around max-w-2xl mx-auto md:max-w-full">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center justify-center flex-1 h-full py-1 transition-all group cursor-pointer ${
              isActive ? 'text-[#C6FF00]' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {/* Active Pill Glow Bar */}
            {isActive && (
              <span className="absolute top-0 w-8 h-[2px] bg-[#C6FF00] shadow-[0_0_8px_#C6FF00] rounded-full" />
            )}

            <div className="relative">
              <Icon
                className={`w-5 h-5 transition-transform duration-200 ${
                  isActive ? 'scale-110 stroke-[2.2]' : 'group-hover:scale-105'
                }`}
              />
              {tab.badge !== undefined && (
                <span className="absolute -top-1 -right-3 text-[10px] font-mono font-bold px-1.5 py-0.2 bg-[#222] text-[#C6FF00] border border-[#333] rounded-full">
                  {tab.badge}
                </span>
              )}
            </div>

            <span
              className={`text-[11px] font-medium tracking-tight mt-1 transition-colors ${
                isActive ? 'text-[#C6FF00] font-semibold' : 'text-slate-400'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
