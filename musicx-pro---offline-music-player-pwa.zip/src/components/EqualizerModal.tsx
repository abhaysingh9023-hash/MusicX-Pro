import React, { useState } from 'react';
import { Sliders, X, RotateCcw } from 'lucide-react';
import { EqualizerPresetName } from '../types/music';
import { audioEngine, EQ_FREQUENCIES, EQ_PRESETS } from '../services/audioEngine';

interface EqualizerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EqualizerModal: React.FC<EqualizerModalProps> = ({ isOpen, onClose }) => {
  const currentEq = audioEngine.getEqualizerState();
  const [activePreset, setActivePreset] = useState<EqualizerPresetName>(currentEq.preset);
  const [gains, setGains] = useState<[number, number, number, number, number]>(currentEq.gains);

  if (!isOpen) return null;

  const handlePresetSelect = (presetName: EqualizerPresetName) => {
    setActivePreset(presetName);
    audioEngine.setEqualizerPreset(presetName);
    const updated = audioEngine.getEqualizerState();
    setGains(updated.gains);
  };

  const handleGainChange = (bandIndex: number, valueStr: string) => {
    const val = parseFloat(valueStr);
    const newGains = [...gains] as [number, number, number, number, number];
    newGains[bandIndex] = val;
    setGains(newGains);
    setActivePreset('Custom');
    audioEngine.setBandGain(bandIndex, val);
  };

  const handleReset = () => {
    handlePresetSelect('Flat');
  };

  const presetsList: EqualizerPresetName[] = [
    'Flat',
    'Bass Boost',
    'Electronic',
    'Rock',
    'Vocal Boost',
    'Acoustic',
    'Hip-Hop',
    'Pop',
  ];

  const frequencyLabels = ['60 Hz', '230 Hz', '910 Hz', '4 kHz', '14 kHz'];
  const frequencyBands = ['Sub-Bass', 'Bass', 'Mid', 'Presence', 'Brilliance'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-[#141414] border border-[#282828] p-6 shadow-2xl text-slate-100 flex flex-col gap-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#C6FF00]/10 border border-[#C6FF00]/30 flex items-center justify-center text-[#C6FF00]">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">5-Band Equalizer</h2>
              <p className="text-xs text-slate-400">Hardware-accelerated audio filtering</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="p-2 text-xs font-medium text-slate-400 hover:text-[#C6FF00] rounded-xl hover:bg-[#202020] transition flex items-center gap-1.5"
              title="Reset to Flat"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-[#202020] transition"
              aria-label="Close Equalizer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Presets Bar */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5 block">
            Acoustic Presets
          </label>
          <div className="flex flex-wrap gap-2">
            {presetsList.map((preset) => (
              <button
                key={preset}
                onClick={() => handlePresetSelect(preset)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  activePreset === preset
                    ? 'bg-[#C6FF00] text-black font-bold shadow-md shadow-[#C6FF00]/25'
                    : 'bg-[#1F1F1F] text-slate-300 hover:bg-[#2A2A2A] hover:text-white border border-[#2A2A2A]'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* 5 Vertical Band Sliders */}
        <div className="bg-[#1A1A1A] p-5 rounded-2xl border border-[#262626]">
          <div className="grid grid-cols-5 gap-2 items-center text-center">
            {EQ_FREQUENCIES.map((freq, idx) => {
              const currentGain = gains[idx] ?? 0;
              return (
                <div key={freq} className="flex flex-col items-center gap-3">
                  <span className="text-[11px] font-mono font-semibold text-[#C6FF00] tabular-nums">
                    {currentGain > 0 ? `+${currentGain}` : currentGain}dB
                  </span>

                  <div className="h-40 flex items-center justify-center py-2 relative">
                    {/* Zero dB midline guide */}
                    <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-slate-700/60 pointer-events-none" />

                    <input
                      type="range"
                      min="-12"
                      max="12"
                      step="0.5"
                      value={currentGain}
                      onChange={(e) => handleGainChange(idx, e.target.value)}
                      className="w-32 h-6 -rotate-90 origin-center accent-[#C6FF00] cursor-pointer"
                      aria-label={`${frequencyLabels[idx]} Gain`}
                    />
                  </div>

                  <div className="flex flex-col items-center">
                    <span className="text-xs font-semibold text-white tracking-tight">
                      {frequencyLabels[idx]}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {frequencyBands[idx]}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer info & close */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-[#222]">
          <span>Current profile: <strong className="text-white">{activePreset}</strong></span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C6FF00] text-black font-bold hover:brightness-110 active:scale-95 transition"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};
