import React, { useState } from 'react';
import {
  ChevronDown,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  RotateCw,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  Volume2,
  VolumeX,
  Sliders,
  Moon,
  ListPlus,
} from 'lucide-react';
import { Song, RepeatMode, SleepTimerState } from '../types/music';
import { AudioVisualizer } from './AudioVisualizer';
import { EqualizerModal } from './EqualizerModal';
import { SleepTimerModal } from './SleepTimerModal';

interface FullScreenPlayerProps {
  isOpen: boolean;
  onClose: () => void;
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  sleepTimer: SleepTimerState;
  setSleepTimer: React.Dispatch<React.SetStateAction<SleepTimerState>>;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek: (time: number) => void;
  onSkipSeconds: (delta: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleFavorite: (songId: string) => void;
  onAddToPlaylist: (song: Song) => void;
}

export const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({
  isOpen,
  onClose,
  currentSong,
  isPlaying,
  currentTime,
  duration,
  volume,
  isShuffle,
  repeatMode,
  sleepTimer,
  setSleepTimer,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onSkipSeconds,
  onVolumeChange,
  onToggleShuffle,
  onToggleRepeat,
  onToggleFavorite,
  onAddToPlaylist,
}) => {
  const [showEq, setShowEq] = useState(false);
  const [showSleep, setShowSleep] = useState(false);
  const [prevVolume, setPrevVolume] = useState(1);

  if (!isOpen || !currentSong) return null;

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleMuteToggle = () => {
    if (volume > 0) {
      setPrevVolume(volume);
      onVolumeChange(0);
    } else {
      onVolumeChange(prevVolume || 0.8);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-gradient-to-b from-[#141414] via-[#0F0F0F] to-[#0A0A0A] text-slate-100 overflow-y-auto animate-in slide-in-from-bottom duration-300">
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-[#202020]/60 shrink-0">
        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-[#181818] hover:bg-[#252525] text-slate-300 hover:text-white transition active:scale-95 cursor-pointer"
          aria-label="Minimize Player"
        >
          <ChevronDown className="w-5 h-5" />
        </button>

        <div className="text-center">
          <span className="text-[11px] font-semibold tracking-widest uppercase text-[#C6FF00]">
            Now Playing
          </span>
          <p className="text-xs text-slate-400 font-medium truncate max-w-[200px]">
            {currentSong.album || 'Offline Library'}
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Equalizer trigger */}
          <button
            onClick={() => setShowEq(true)}
            className="p-2.5 rounded-full bg-[#181818] hover:bg-[#252525] text-slate-300 hover:text-[#C6FF00] transition active:scale-95 cursor-pointer"
            title="5-Band Equalizer"
          >
            <Sliders className="w-4 h-4" />
          </button>

          {/* Sleep Timer trigger */}
          <button
            onClick={() => setShowSleep(true)}
            className={`p-2.5 rounded-full transition active:scale-95 relative cursor-pointer ${
              sleepTimer.isActive
                ? 'bg-[#C6FF00] text-black font-bold'
                : 'bg-[#181818] hover:bg-[#252525] text-slate-300 hover:text-white'
            }`}
            title="Sleep Timer"
          >
            <Moon className="w-4 h-4" />
            {sleepTimer.isActive && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {/* Center Artwork & Visualizer Container */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-4 max-w-lg mx-auto w-full gap-5">
        {/* Large Artwork */}
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl overflow-hidden shadow-2xl shadow-black/80 border border-[#252525] group">
          <img
            src={currentSong.coverUrl}
            alt={currentSong.title}
            referrerPolicy="no-referrer"
            className={`w-full h-full object-cover transition-transform duration-700 ${
              isPlaying ? 'scale-105' : 'scale-100'
            }`}
          />

          {/* Neon Lime Edge Glow */}
          <div
            className={`absolute inset-0 pointer-events-none rounded-3xl transition-opacity duration-500 ring-2 ring-inset ${
              isPlaying ? 'ring-[#C6FF00]/50 shadow-[inset_0_0_40px_rgba(198,255,0,0.2)]' : 'ring-transparent'
            }`}
          />
        </div>

        {/* Live Audio Visualizer Spectrum */}
        <div className="w-full px-2">
          <AudioVisualizer isPlaying={isPlaying} barCount={28} height={60} />
        </div>

        {/* Song Info & Favorite */}
        <div className="w-full flex items-center justify-between gap-4 pt-1">
          <div className="min-w-0 flex-1">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight truncate">
              {currentSong.title}
            </h1>
            <p className="text-sm font-medium text-slate-400 truncate mt-0.5">
              {currentSong.artist}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onAddToPlaylist(currentSong)}
              className="p-2.5 rounded-full bg-[#181818] hover:bg-[#252525] text-slate-300 hover:text-white transition active:scale-95"
              title="Add to Playlist"
            >
              <ListPlus className="w-5 h-5" />
            </button>
            <button
              onClick={() => onToggleFavorite(currentSong.id)}
              className={`p-2.5 rounded-full transition active:scale-95 ${
                currentSong.isFavorite
                  ? 'bg-rose-500/20 text-rose-500'
                  : 'bg-[#181818] text-slate-400 hover:text-white hover:bg-[#252525]'
              }`}
              title={currentSong.isFavorite ? 'Remove Favorite' : 'Mark Favorite'}
            >
              <Heart
                className="w-5 h-5"
                fill={currentSong.isFavorite ? 'currentColor' : 'none'}
              />
            </button>
          </div>
        </div>

        {/* Progress Seek Bar */}
        <div className="w-full space-y-1.5">
          <input
            type="range"
            min="0"
            max={duration || 100}
            step="0.1"
            value={currentTime}
            onChange={(e) => onSeek(parseFloat(e.target.value))}
            className="w-full h-2 rounded-full cursor-pointer"
            aria-label="Seek track position"
          />
          <div className="flex justify-between text-xs font-mono text-slate-400 tabular-nums">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Playback Controls Row */}
        <div className="w-full flex items-center justify-between max-w-md pt-2">
          {/* Shuffle */}
          <button
            onClick={onToggleShuffle}
            className={`p-2.5 rounded-full transition cursor-pointer ${
              isShuffle
                ? 'text-[#C6FF00] bg-[#C6FF00]/15'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title={`Shuffle: ${isShuffle ? 'On' : 'Off'}`}
          >
            <Shuffle className="w-5 h-5" />
          </button>

          {/* Skip -10s */}
          <button
            onClick={() => onSkipSeconds(-10)}
            className="p-2.5 text-slate-300 hover:text-white hover:bg-[#1C1C1C] rounded-full transition cursor-pointer flex flex-col items-center"
            title="Rewind 10 seconds"
          >
            <RotateCcw className="w-5 h-5" />
            <span className="text-[9px] font-mono font-bold mt-0.5">10s</span>
          </button>

          {/* Previous Track */}
          <button
            onClick={onPrev}
            className="p-3 text-slate-200 hover:text-white hover:bg-[#222] rounded-full transition cursor-pointer active:scale-95"
            title="Previous Song"
          >
            <SkipBack className="w-6 h-6" />
          </button>

          {/* Main Play / Pause Button */}
          <button
            onClick={onTogglePlay}
            className="w-16 h-16 rounded-full bg-[#C6FF00] text-black flex items-center justify-center shadow-xl shadow-[#C6FF00]/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-7 h-7 fill-black" />
            ) : (
              <Play className="w-7 h-7 fill-black translate-x-0.5" />
            )}
          </button>

          {/* Next Track */}
          <button
            onClick={onNext}
            className="p-3 text-slate-200 hover:text-white hover:bg-[#222] rounded-full transition cursor-pointer active:scale-95"
            title="Next Song"
          >
            <SkipForward className="w-6 h-6" />
          </button>

          {/* Skip +10s */}
          <button
            onClick={() => onSkipSeconds(10)}
            className="p-2.5 text-slate-300 hover:text-white hover:bg-[#1C1C1C] rounded-full transition cursor-pointer flex flex-col items-center"
            title="Forward 10 seconds"
          >
            <RotateCw className="w-5 h-5" />
            <span className="text-[9px] font-mono font-bold mt-0.5">10s</span>
          </button>

          {/* Repeat Mode */}
          <button
            onClick={onToggleRepeat}
            className={`p-2.5 rounded-full transition cursor-pointer ${
              repeatMode !== 'off'
                ? 'text-[#C6FF00] bg-[#C6FF00]/15'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title={`Repeat: ${repeatMode}`}
          >
            {repeatMode === 'one' ? (
              <Repeat1 className="w-5 h-5" />
            ) : (
              <Repeat className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Volume Slider Row */}
        <div className="w-full flex items-center gap-3 max-w-sm pt-2">
          <button
            onClick={handleMuteToggle}
            className="p-1.5 text-slate-400 hover:text-white transition cursor-pointer"
            title={volume === 0 ? 'Unmute' : 'Mute'}
          >
            {volume === 0 ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-slate-300" />
            )}
          </button>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
            className="w-full h-1.5 rounded-full cursor-pointer"
            aria-label="Volume slider"
          />
          <span className="text-[11px] font-mono text-slate-400 w-8 text-right tabular-nums">
            {Math.round(volume * 100)}%
          </span>
        </div>
      </div>

      {/* Bottom spacer safe area */}
      <div className="pb-safe" />

      {/* Equalizer Modal */}
      <EqualizerModal isOpen={showEq} onClose={() => setShowEq(false)} />

      {/* Sleep Timer Modal */}
      <SleepTimerModal
        isOpen={showSleep}
        onClose={() => setShowSleep(false)}
        sleepTimer={sleepTimer}
        setSleepTimer={setSleepTimer}
      />
    </div>
  );
};
