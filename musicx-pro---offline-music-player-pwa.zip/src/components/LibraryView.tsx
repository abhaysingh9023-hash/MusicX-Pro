import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  Shuffle,
  FolderPlus,
  Search,
  Heart,
  ArrowUpDown,
  MoreVertical,
  ListPlus,
  Trash2,
  Music,
  Plus,
  SkipForward,
  SkipBack,
} from 'lucide-react';
import { Song, SortOption } from '../types/music';
import { PWAInstallButton } from './PWAInstallButton';
import { AudioVisualizer } from './AudioVisualizer';

interface LibraryViewProps {
  songs: Song[];
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onSelectSong: (song: Song) => void;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek: (time: number) => void;
  onShuffleAll: () => void;
  onToggleFavorite: (songId: string) => void;
  onDeleteSong: (songId: string) => void;
  onAddToPlaylist: (song: Song) => void;
  onAddFilesClick: () => void;
  onAddFolderClick: () => void;
  onOpenFullScreen: () => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  songs,
  currentSong,
  isPlaying,
  currentTime,
  duration,
  onSelectSong,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onShuffleAll,
  onToggleFavorite,
  onDeleteSong,
  onAddToPlaylist,
  onAddFilesClick,
  onAddFolderClick,
  onOpenFullScreen,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('recent');
  const [activeMenuSongId, setActiveMenuSongId] = useState<string | null>(null);
  const [showAddMenu, setShowAddMenu] = useState(false);

  // Filter & Sort Logic
  const filteredSongs = useMemo(() => {
    let result = [...songs];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.artist.toLowerCase().includes(q) ||
          (s.album && s.album.toLowerCase().includes(q))
      );
    }

    // Favorites only filter
    if (favoritesOnly) {
      result = result.filter((s) => s.isFavorite);
    }

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'recent') {
        return b.dateAdded - a.dateAdded;
      }
      if (sortBy === 'title-asc') {
        return a.title.localeCompare(b.title);
      }
      if (sortBy === 'title-desc') {
        return b.title.localeCompare(a.title);
      }
      if (sortBy === 'artist-asc') {
        return a.artist.localeCompare(b.artist);
      }
      if (sortBy === 'duration-desc') {
        return b.duration - a.duration;
      }
      return 0;
    });

    return result;
  }, [songs, searchQuery, favoritesOnly, sortBy]);

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Header with Song Count Badge & Install Button */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#1E2E10] to-[#121212] border border-[#C6FF00]/40 flex items-center justify-center text-[#C6FF00] shadow-md shadow-[#C6FF00]/10">
            <span className="font-extrabold text-base tracking-tighter">MX</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                MusicX <span className="text-[#C6FF00]">Pro</span>
              </h1>
              <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded-full bg-[#1A1A1A] text-[#C6FF00] border border-[#2A2A2A]">
                {songs.length} {songs.length === 1 ? 'Track' : 'Tracks'}
              </span>
            </div>
            <p className="text-xs text-slate-400">Offline Hi-Fi Player</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <PWAInstallButton compact />
        </div>
      </div>

      {/* Prominent 'Now Playing' Hero Card */}
      {currentSong && (
        <div className="relative rounded-3xl bg-gradient-to-r from-[#171717] via-[#141414] to-[#101010] border border-[#262626] p-5 sm:p-6 shadow-2xl overflow-hidden group">
          {/* Subtle background ambient blur from cover */}
          <div
            className="absolute -right-10 -bottom-10 w-64 h-64 rounded-full opacity-15 blur-3xl pointer-events-none"
            style={{
              backgroundImage: `url(${currentSong.coverUrl})`,
              backgroundSize: 'cover',
            }}
          />

          <div className="relative z-10 flex flex-col md:flex-row items-center gap-5 sm:gap-6">
            {/* Album Art with Vinyl / Pulse Glow */}
            <div
              onClick={onOpenFullScreen}
              className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-2xl overflow-hidden shrink-0 border border-[#2D2D2D] shadow-xl cursor-pointer group/art"
              title="Click to expand full player"
            >
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover transition-transform duration-700 ${
                  isPlaying ? 'scale-105' : 'scale-100 group-hover/art:scale-105'
                }`}
              />

              {/* Glowing play overlay on hover */}
              <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] opacity-0 group-hover/art:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-xs font-bold text-white bg-black/70 px-3 py-1.5 rounded-xl border border-white/20">
                  Expand Player
                </span>
              </div>
            </div>

            {/* Song Info & Interactive Controls */}
            <div className="flex-1 min-w-0 w-full flex flex-col justify-between gap-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <span className="text-[11px] font-bold text-[#C6FF00] tracking-widest uppercase flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#C6FF00] inline-block shadow-[0_0_8px_#C6FF00]" />
                    Now Playing
                  </span>
                  <h2
                    onClick={onOpenFullScreen}
                    className="text-lg sm:text-2xl font-bold text-white tracking-tight truncate mt-1 hover:text-[#C6FF00] transition-colors cursor-pointer"
                  >
                    {currentSong.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 font-medium truncate mt-0.5">
                    {currentSong.artist} · {currentSong.album || 'Offline Audio'}
                  </p>
                </div>

                <button
                  onClick={() => onToggleFavorite(currentSong.id)}
                  className={`p-2.5 rounded-2xl border transition ${
                    currentSong.isFavorite
                      ? 'bg-rose-500/15 border-rose-500/40 text-rose-500'
                      : 'bg-[#1C1C1C] border-[#2A2A2A] text-slate-400 hover:text-white'
                  }`}
                  title={currentSong.isFavorite ? 'Remove Favorite' : 'Mark Favorite'}
                >
                  <Heart
                    className="w-5 h-5"
                    fill={currentSong.isFavorite ? 'currentColor' : 'none'}
                  />
                </button>
              </div>

              {/* Mini Spectrum Visualizer inside Hero */}
              <div className="w-full">
                <AudioVisualizer isPlaying={isPlaying} barCount={36} height={36} />
              </div>

              {/* Seek Bar */}
              <div className="w-full space-y-1">
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  step="0.1"
                  value={currentTime}
                  onChange={(e) => onSeek(parseFloat(e.target.value))}
                  className="w-full h-1.5 rounded-full cursor-pointer"
                  aria-label="Seek track position"
                />
                <div className="flex justify-between text-[11px] font-mono text-slate-400 tabular-nums">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* Playback Button Controls */}
              <div className="flex items-center justify-between sm:justify-start sm:gap-4 pt-1">
                <button
                  onClick={onPrev}
                  className="p-2.5 text-slate-300 hover:text-white hover:bg-[#222] rounded-xl transition cursor-pointer active:scale-95"
                  title="Previous Track"
                >
                  <SkipBack className="w-5 h-5" />
                </button>

                <button
                  onClick={onTogglePlay}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-[#C6FF00] text-black font-extrabold text-xs shadow-lg shadow-[#C6FF00]/25 hover:brightness-110 active:scale-95 transition cursor-pointer"
                  title={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="w-4 h-4 fill-black" />
                      <span>Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-black translate-x-0.5" />
                      <span>Play Track</span>
                    </>
                  )}
                </button>

                <button
                  onClick={onNext}
                  className="p-2.5 text-slate-300 hover:text-white hover:bg-[#222] rounded-xl transition cursor-pointer active:scale-95"
                  title="Next Track"
                >
                  <SkipForward className="w-5 h-5" />
                </button>

                <button
                  onClick={onOpenFullScreen}
                  className="text-xs font-semibold text-slate-400 hover:text-[#C6FF00] px-3 py-1.5 rounded-xl hover:bg-[#202020] transition hidden sm:inline-block ml-auto"
                >
                  Full View →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quick Action Buttons: 'Shuffle All' and '+ Add Songs / Folder' */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <button
          onClick={onShuffleAll}
          disabled={songs.length === 0}
          className="flex items-center gap-2.5 px-5 py-3 rounded-2xl bg-[#C6FF00] text-black font-extrabold text-xs shadow-lg shadow-[#C6FF00]/20 hover:brightness-110 active:scale-95 disabled:opacity-50 transition cursor-pointer"
        >
          <Shuffle className="w-4 h-4" />
          <span>Shuffle All ({songs.length})</span>
        </button>

        {/* Add Songs / Folder Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowAddMenu(!showAddMenu)}
            className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-[#1A1A1A] border border-[#2E2E2E] hover:border-[#C6FF00]/50 text-slate-200 hover:text-white text-xs font-bold transition active:scale-95 cursor-pointer"
          >
            <FolderPlus className="w-4 h-4 text-[#C6FF00]" />
            <span>+ Add Songs / Folder</span>
          </button>

          {showAddMenu && (
            <div className="absolute right-0 top-full mt-2 w-56 rounded-2xl bg-[#161616] border border-[#2E2E2E] shadow-2xl p-2 z-30 animate-in fade-in duration-150">
              <button
                onClick={() => {
                  setShowAddMenu(false);
                  onAddFilesClick();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-[#222] transition text-left cursor-pointer"
              >
                <Plus className="w-4 h-4 text-[#C6FF00]" />
                <div>
                  <div>Select Audio Files</div>
                  <div className="text-[10px] text-slate-400 font-normal">MP3, WAV, AAC, FLAC</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowAddMenu(false);
                  onAddFolderClick();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-[#222] transition text-left cursor-pointer mt-1"
              >
                <FolderPlus className="w-4 h-4 text-[#C6FF00]" />
                <div>
                  <div>Import Entire Folder</div>
                  <div className="text-[10px] text-slate-400 font-normal">Add all songs inside directory</div>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Smart Search & Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search songs, artists, albums..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-[#161616] border border-[#262626] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C6FF00] transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Favorites Filter Toggle */}
          <button
            onClick={() => setFavoritesOnly(!favoritesOnly)}
            className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl border text-xs font-semibold transition active:scale-95 cursor-pointer ${
              favoritesOnly
                ? 'bg-rose-500/15 border-rose-500 text-rose-400'
                : 'bg-[#161616] border-[#262626] text-slate-400 hover:text-slate-200'
            }`}
          >
            <Heart
              className="w-3.5 h-3.5"
              fill={favoritesOnly ? 'currentColor' : 'none'}
            />
            <span>Favorites</span>
          </button>

          {/* Sort Dropdown */}
          <div className="relative flex items-center">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="pl-8 pr-8 py-2.5 rounded-2xl bg-[#161616] border border-[#262626] text-xs font-semibold text-slate-200 focus:outline-none focus:border-[#C6FF00] cursor-pointer appearance-none"
            >
              <option value="recent">Recently Added</option>
              <option value="title-asc">Title (A - Z)</option>
              <option value="title-desc">Title (Z - A)</option>
              <option value="artist-asc">Artist (A - Z)</option>
              <option value="duration-desc">Duration (Longest)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Song List Section */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400 px-3 py-1">
          <span># · TITLE & ARTIST</span>
          <span>DURATION & ACTIONS</span>
        </div>

        {filteredSongs.length === 0 ? (
          <div className="p-10 rounded-3xl bg-[#141414] border border-[#222] text-center space-y-3">
            <Music className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">
              {searchQuery || favoritesOnly ? 'No matching songs found' : 'Your library is empty'}
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {searchQuery || favoritesOnly
                ? 'Try clearing your search query or disabling the favorites filter.'
                : 'Click "+ Add Songs / Folder" to import audio from your device.'}
            </p>
            {!searchQuery && !favoritesOnly && (
              <button
                onClick={onAddFilesClick}
                className="px-5 py-2.5 rounded-xl bg-[#C6FF00] text-black font-bold text-xs inline-flex items-center gap-2 mt-2"
              >
                <FolderPlus className="w-4 h-4" />
                <span>Add Local Music</span>
              </button>
            )}
          </div>
        ) : (
          <div className="divide-y divide-[#1F1F1F] rounded-3xl bg-[#141414] border border-[#242424] overflow-hidden">
            {filteredSongs.map((song, idx) => {
              const isCurrent = currentSong?.id === song.id;

              return (
                <div
                  key={song.id}
                  onClick={() => onSelectSong(song)}
                  className={`flex items-center justify-between p-3.5 transition-all cursor-pointer group ${
                    isCurrent
                      ? 'bg-[#C6FF00]/10 text-white'
                      : 'hover:bg-[#1A1A1A]'
                  }`}
                >
                  {/* Left: Index / Wave, Cover, Title, Artist */}
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className="w-6 text-center text-xs font-mono text-slate-400 shrink-0">
                      {isCurrent && isPlaying ? (
                        <span className="flex items-end justify-center gap-0.5 h-4">
                          <span className="w-0.5 h-3 bg-[#C6FF00] animate-bounce" />
                          <span className="w-0.5 h-4 bg-[#C6FF00] animate-bounce [animation-delay:0.15s]" />
                          <span className="w-0.5 h-2 bg-[#C6FF00] animate-bounce [animation-delay:0.3s]" />
                        </span>
                      ) : (
                        <span className="group-hover:hidden">{idx + 1}</span>
                      )}
                      <Play className="w-4 h-4 text-[#C6FF00] hidden group-hover:block mx-auto" />
                    </div>

                    <div className="w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-[#282828] shadow-sm">
                      <img
                        src={song.coverUrl}
                        alt={song.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div
                        className={`text-sm font-semibold truncate ${
                          isCurrent ? 'text-[#C6FF00]' : 'text-white group-hover:text-[#C6FF00]'
                        } transition-colors`}
                      >
                        {song.title}
                      </div>
                      <div className="text-xs text-slate-400 truncate mt-0.5">
                        {song.artist} {song.album ? `· ${song.album}` : ''}
                      </div>
                    </div>
                  </div>

                  {/* Right: Duration, Favorite, More Options */}
                  <div
                    className="flex items-center gap-2 sm:gap-3 shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <span className="text-xs font-mono text-slate-400 tabular-nums">
                      {formatTime(song.duration)}
                    </span>

                    <button
                      onClick={() => onToggleFavorite(song.id)}
                      className={`p-2 rounded-xl transition ${
                        song.isFavorite
                          ? 'text-rose-500 hover:bg-rose-500/10'
                          : 'text-slate-500 hover:text-white hover:bg-[#242424]'
                      }`}
                      title={song.isFavorite ? 'Remove Favorite' : 'Favorite'}
                    >
                      <Heart
                        className="w-4 h-4"
                        fill={song.isFavorite ? 'currentColor' : 'none'}
                      />
                    </button>

                    <div className="relative">
                      <button
                        onClick={() =>
                          setActiveMenuSongId(
                            activeMenuSongId === song.id ? null : song.id
                          )
                        }
                        className="p-2 text-slate-400 hover:text-white hover:bg-[#242424] rounded-xl transition cursor-pointer"
                        title="More options"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>

                      {activeMenuSongId === song.id && (
                        <div className="absolute right-0 top-full mt-1 w-44 rounded-2xl bg-[#1A1A1A] border border-[#2E2E2E] shadow-2xl p-1.5 z-30 animate-in fade-in duration-100">
                          <button
                            onClick={() => {
                              setActiveMenuSongId(null);
                              onAddToPlaylist(song);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-slate-200 hover:text-white hover:bg-[#262626] transition text-left cursor-pointer"
                          >
                            <ListPlus className="w-4 h-4 text-[#C6FF00]" />
                            <span>Add to Playlist</span>
                          </button>
                          <button
                            onClick={() => {
                              setActiveMenuSongId(null);
                              if (window.confirm(`Delete "${song.title}"?`)) {
                                onDeleteSong(song.id);
                              }
                            }}
                            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-red-400 hover:bg-red-500/10 transition text-left cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                            <span>Delete Song</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
