import React from 'react';
import { Play, Pause, SkipForward, SkipBack, Heart, Maximize2 } from 'lucide-react';
import { Song } from '../types/music';

interface MiniPlayerProps {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onTogglePlay: (e: React.MouseEvent) => void;
  onNext: (e: React.MouseEvent) => void;
  onPrev: (e: React.MouseEvent) => void;
  onToggleFavorite: (e: React.MouseEvent, songId: string) => void;
  onOpenFullScreen: () => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  currentSong,
  isPlaying,
  currentTime,
  duration,
  onTogglePlay,
  onNext,
  onPrev,
  onToggleFavorite,
  onOpenFullScreen,
}) => {
  if (!currentSong) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div
      onClick={onOpenFullScreen}
      className="fixed bottom-[68px] left-3 right-3 md:left-1/2 md:-translate-x-1/2 md:w-[580px] z-30 bg-[#161616]/95 backdrop-blur-2xl border border-[#282828] hover:border-[#C6FF00]/40 rounded-2xl shadow-2xl p-2.5 transition-all duration-200 cursor-pointer group"
      role="button"
      tabIndex={0}
      aria-label="Open Fullscreen Player"
    >
      {/* Top Hairline Progress Line */}
      <div className="absolute top-0 left-3 right-3 h-[2px] bg-[#222] rounded-full overflow-hidden">
        <div
          className="h-full bg-[#C6FF00] shadow-[0_0_8px_rgba(198,255,0,0.8)] transition-all duration-150"
          style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
        />
      </div>

      <div className="flex items-center justify-between gap-3 pt-1">
        {/* Album Artwork & Metadata */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="relative w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-[#282828] shadow-md">
            <img
              src={currentSong.coverUrl}
              alt={currentSong.title}
              referrerPolicy="no-referrer"
              className={`w-full h-full object-cover transition-transform duration-500 ${
                isPlaying ? 'scale-110' : 'scale-100'
              }`}
            />
            {isPlaying && (
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full bg-[#C6FF00] shadow-[0_0_6px_#C6FF00] animate-ping" />
              </div>
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h4 className="text-xs sm:text-sm font-bold text-white truncate group-hover:text-[#C6FF00] transition-colors">
                {currentSong.title}
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 font-medium truncate mt-0.5">
              {currentSong.artist}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
          {/* Favorite */}
          <button
            onClick={(e) => onToggleFavorite(e, currentSong.id)}
            className={`p-2 rounded-xl transition ${
              currentSong.isFavorite
                ? 'text-rose-500 hover:bg-rose-500/10'
                : 'text-slate-400 hover:text-white hover:bg-[#222]'
            }`}
            title="Favorite"
          >
            <Heart className="w-4 h-4" fill={currentSong.isFavorite ? 'currentColor' : 'none'} />
          </button>

          {/* Previous */}
          <button
            onClick={onPrev}
            className="p-2 text-slate-300 hover:text-white hover:bg-[#222] rounded-xl transition hidden sm:flex"
            title="Previous"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          {/* Play / Pause Neon Button */}
          <button
            onClick={onTogglePlay}
            className="w-10 h-10 rounded-xl bg-[#C6FF00] text-black flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-[#C6FF00]/25 cursor-pointer"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-black" />
            ) : (
              <Play className="w-4 h-4 fill-black translate-x-0.5" />
            )}
          </button>

          {/* Next */}
          <button
            onClick={onNext}
            className="p-2 text-slate-300 hover:text-white hover:bg-[#222] rounded-xl transition"
            title="Next"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          {/* Expand */}
          <button
            onClick={onOpenFullScreen}
            className="p-2 text-slate-400 hover:text-[#C6FF00] hover:bg-[#222] rounded-xl transition"
            title="Expand Full Player"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
