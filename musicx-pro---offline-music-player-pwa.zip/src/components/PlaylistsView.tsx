import React, { useState } from 'react';
import {
  Plus,
  Play,
  Shuffle,
  Trash2,
  Edit2,
  ArrowLeft,
  Music,
  ListMusic,
  Check,
  X,
  PlusCircle,
} from 'lucide-react';
import { Playlist, Song } from '../types/music';

interface PlaylistsViewProps {
  playlists: Playlist[];
  songs: Song[];
  currentSongId: string | null;
  isPlaying: boolean;
  onCreatePlaylist: (name: string) => Promise<Playlist>;
  onRenamePlaylist: (id: string, name: string) => Promise<void>;
  onDeletePlaylist: (id: string) => Promise<void>;
  onRemoveSongFromPlaylist: (playlistId: string, songId: string) => Promise<void>;
  onAddSongToPlaylist: (playlistId: string, songId: string) => Promise<void>;
  onPlayPlaylist: (playlist: Playlist, shuffle?: boolean) => void;
  onSelectSong: (song: Song) => void;
}

export const PlaylistsView: React.FC<PlaylistsViewProps> = ({
  playlists,
  songs,
  currentSongId,
  isPlaying,
  onCreatePlaylist,
  onRenamePlaylist,
  onDeletePlaylist,
  onRemoveSongFromPlaylist,
  onAddSongToPlaylist,
  onPlayPlaylist,
  onSelectSong,
}) => {
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlaylistTitle, setNewPlaylistTitle] = useState('');
  const [editingPlaylistId, setEditingPlaylistId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [showAddSongsModal, setShowAddSongsModal] = useState(false);

  const selectedPlaylist = playlists.find((p) => p.id === selectedPlaylistId);
  const playlistSongs = selectedPlaylist
    ? selectedPlaylist.songIds
        .map((id) => songs.find((s) => s.id === id))
        .filter((s): s is Song => Boolean(s))
    : [];

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistTitle.trim()) return;
    const pl = await onCreatePlaylist(newPlaylistTitle.trim());
    setNewPlaylistTitle('');
    setShowCreateModal(false);
    setSelectedPlaylistId(pl.id);
  };

  const handleStartRename = (pl: Playlist) => {
    setEditingPlaylistId(pl.id);
    setEditTitle(pl.name);
  };

  const handleSaveRename = async (playlistId: string) => {
    if (editTitle.trim()) {
      await onRenamePlaylist(playlistId, editTitle.trim());
    }
    setEditingPlaylistId(null);
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const totalPlaylistDuration = playlistSongs.reduce((acc, s) => acc + s.duration, 0);

  // If viewing a single playlist
  if (selectedPlaylist) {
    const availableSongsToAdd = songs.filter(
      (s) => !selectedPlaylist.songIds.includes(s.id)
    );

    return (
      <div className="space-y-6">
        {/* Detail Header */}
        <div className="flex items-center justify-between gap-4">
          <button
            onClick={() => setSelectedPlaylistId(null)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] text-slate-300 hover:text-white transition text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All Playlists</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleStartRename(selectedPlaylist)}
              className="p-2 rounded-xl bg-[#1A1A1A] hover:bg-[#252525] text-slate-300 hover:text-white transition"
              title="Rename Playlist"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                if (window.confirm(`Delete playlist "${selectedPlaylist.name}"?`)) {
                  onDeletePlaylist(selectedPlaylist.id);
                  setSelectedPlaylistId(null);
                }
              }}
              className="p-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 transition"
              title="Delete Playlist"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Playlist Hero Banner */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 p-5 rounded-3xl bg-[#161616] border border-[#252525]">
          <div className="w-24 h-24 rounded-2xl bg-[#202020] border border-[#303030] overflow-hidden shrink-0 flex items-center justify-center shadow-lg">
            {playlistSongs.length > 0 && playlistSongs[0].coverUrl ? (
              <img
                src={playlistSongs[0].coverUrl}
                alt={selectedPlaylist.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <Music className="w-10 h-10 text-slate-500" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <span className="text-[11px] font-semibold text-[#C6FF00] uppercase tracking-wider">
              Playlist
            </span>

            {editingPlaylistId === selectedPlaylist.id ? (
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="px-2.5 py-1 text-base font-bold bg-[#222] border border-[#C6FF00] rounded-lg text-white focus:outline-none"
                  autoFocus
                />
                <button
                  onClick={() => handleSaveRename(selectedPlaylist.id)}
                  className="p-1.5 rounded-lg bg-[#C6FF00] text-black font-bold"
                >
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight truncate mt-0.5">
                {selectedPlaylist.name}
              </h1>
            )}

            <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
              <span>{playlistSongs.length} {playlistSongs.length === 1 ? 'song' : 'songs'}</span>
              <span>·</span>
              <span>{formatDuration(totalPlaylistDuration)} total duration</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0">
            <button
              onClick={() => onPlayPlaylist(selectedPlaylist, false)}
              disabled={playlistSongs.length === 0}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#C6FF00] text-black font-bold text-xs shadow-lg shadow-[#C6FF00]/20 hover:brightness-110 active:scale-95 disabled:opacity-50 transition cursor-pointer"
            >
              <Play className="w-4 h-4 fill-black" />
              <span>Play All</span>
            </button>
            <button
              onClick={() => onPlayPlaylist(selectedPlaylist, true)}
              disabled={playlistSongs.length === 0}
              className="p-2.5 rounded-xl bg-[#222] text-slate-200 hover:text-[#C6FF00] hover:bg-[#282828] active:scale-95 disabled:opacity-50 transition cursor-pointer"
              title="Shuffle Playlist"
            >
              <Shuffle className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowAddSongsModal(true)}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-[#333] hover:border-[#C6FF00]/50 text-slate-200 hover:text-white transition text-xs font-semibold cursor-pointer"
              title="Add Songs to Playlist"
            >
              <PlusCircle className="w-4 h-4 text-[#C6FF00]" />
              <span className="hidden md:inline">Add Songs</span>
            </button>
          </div>
        </div>

        {/* Songs List */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-400 px-3 py-1">
            <span>TRACK / TITLE</span>
            <span>DURATION / ACTION</span>
          </div>

          {playlistSongs.length === 0 ? (
            <div className="p-8 rounded-3xl bg-[#141414] border border-[#222] text-center space-y-3">
              <p className="text-sm text-slate-400">This playlist is currently empty.</p>
              <button
                onClick={() => setShowAddSongsModal(true)}
                className="px-4 py-2 rounded-xl bg-[#C6FF00] text-black font-bold text-xs inline-flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Songs to Playlist</span>
              </button>
            </div>
          ) : (
            playlistSongs.map((song, idx) => {
              const isCurrent = song.id === currentSongId;
              return (
                <div
                  key={song.id}
                  onClick={() => onSelectSong(song)}
                  className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer group ${
                    isCurrent
                      ? 'bg-[#C6FF00]/10 border-[#C6FF00]/40 text-white'
                      : 'bg-[#161616] border-[#222] hover:bg-[#1C1C1C] hover:border-[#2e2e2e]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <span className="w-5 text-center text-xs font-mono text-slate-400 group-hover:hidden">
                      {idx + 1}
                    </span>
                    <Play className="w-4 h-4 text-[#C6FF00] hidden group-hover:block shrink-0" />

                    <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-[#282828]">
                      <img
                        src={song.coverUrl}
                        alt={song.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-white truncate group-hover:text-[#C6FF00] transition-colors">
                        {song.title}
                      </div>
                      <div className="text-xs text-slate-400 truncate">
                        {song.artist}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0" onClick={(e) => e.stopPropagation()}>
                    <span className="text-xs font-mono text-slate-400 tabular-nums">
                      {formatDuration(song.duration)}
                    </span>
                    <button
                      onClick={() => onRemoveSongFromPlaylist(selectedPlaylist.id, song.id)}
                      className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg hover:bg-[#252525] transition"
                      title="Remove from playlist"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal: Add Songs to this Playlist */}
        {showAddSongsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
            <div className="w-full max-w-md rounded-3xl bg-[#141414] border border-[#282828] p-6 shadow-2xl text-slate-100 flex flex-col gap-4 max-h-[85vh]">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">Add Songs</h3>
                  <p className="text-xs text-slate-400">Select songs to include in "{selectedPlaylist.name}"</p>
                </div>
                <button
                  onClick={() => setShowAddSongsModal(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-[#202020]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="overflow-y-auto space-y-2 pr-1 flex-1 min-h-[200px]">
                {availableSongsToAdd.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">
                    All songs in your library are already in this playlist!
                  </p>
                ) : (
                  availableSongsToAdd.map((s) => (
                    <div
                      key={s.id}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-[#1A1A1A] border border-[#252525]"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <img
                          src={s.coverUrl}
                          alt={s.title}
                          className="w-9 h-9 rounded-lg object-cover shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">{s.title}</p>
                          <p className="text-[11px] text-slate-400 truncate">{s.artist}</p>
                        </div>
                      </div>

                      <button
                        onClick={async () => {
                          await onAddSongToPlaylist(selectedPlaylist.id, s.id);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#C6FF00] text-black text-xs font-bold hover:brightness-110"
                      >
                        Add
                      </button>
                    </div>
                  ))
                )}
              </div>

              <button
                onClick={() => setShowAddSongsModal(false)}
                className="w-full py-2.5 rounded-xl bg-[#222] text-xs font-bold text-slate-200 hover:bg-[#282828]"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // All Playlists Overview Grid
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Playlists</h1>
          <p className="text-xs text-slate-400">Custom offline collections</p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C6FF00] text-black font-bold text-xs shadow-lg shadow-[#C6FF00]/20 hover:brightness-110 active:scale-95 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Playlist</span>
        </button>
      </div>

      {/* Playlists Grid */}
      {playlists.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#141414] border border-[#222] text-center space-y-3">
          <ListMusic className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No playlists yet</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Create custom mixes for gym, study, chillout, or road trips!
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-5 py-2.5 rounded-xl bg-[#C6FF00] text-black font-bold text-xs inline-flex items-center gap-2 mt-2"
          >
            <Plus className="w-4 h-4" />
            <span>Create Playlist</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {playlists.map((pl) => {
            const plSongs = pl.songIds
              .map((id) => songs.find((s) => s.id === id))
              .filter((s): s is Song => Boolean(s));
            const cover = plSongs.length > 0 ? plSongs[0].coverUrl : pl.coverUrl;

            return (
              <div
                key={pl.id}
                onClick={() => setSelectedPlaylistId(pl.id)}
                className="group relative p-4 rounded-3xl bg-[#161616] border border-[#252525] hover:border-[#C6FF00]/40 transition-all cursor-pointer flex flex-col justify-between hover:shadow-xl hover:shadow-[#C6FF00]/5"
              >
                <div>
                  <div className="relative w-full aspect-square rounded-2xl bg-[#202020] border border-[#2c2c2c] overflow-hidden mb-3 flex items-center justify-center">
                    {cover ? (
                      <img
                        src={cover}
                        alt={pl.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <Music className="w-12 h-12 text-slate-600" />
                    )}

                    {/* Quick Play Overlay */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlayPlaylist(pl, false);
                      }}
                      className="absolute bottom-3 right-3 w-11 h-11 rounded-full bg-[#C6FF00] text-black flex items-center justify-center shadow-lg shadow-black/60 opacity-0 group-hover:opacity-100 hover:scale-110 active:scale-95 transition-all"
                      title="Play Playlist"
                    >
                      <Play className="w-5 h-5 fill-black translate-x-0.5" />
                    </button>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-[#C6FF00] transition-colors truncate">
                    {pl.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {pl.songIds.length} {pl.songIds.length === 1 ? 'song' : 'songs'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Playlist Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#141414] border border-[#282828] p-6 shadow-2xl text-slate-100 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Create New Playlist</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#202020]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-400 mb-1.5 block">
                  Playlist Title
                </label>
                <input
                  type="text"
                  placeholder="e.g. Cyber Workout, Late Night Chill"
                  value={newPlaylistTitle}
                  onChange={(e) => setNewPlaylistTitle(e.target.value)}
                  autoFocus
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-[#1A1A1A] border border-[#333] text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#C6FF00]"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-[#222] text-xs font-semibold text-slate-300 hover:bg-[#282828]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C6FF00] text-xs font-bold text-black hover:brightness-110"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
