import React from 'react';
import { Moon, X, Clock, Check } from 'lucide-react';
import { audioEngine } from '../services/audioEngine';
import { SleepTimerState } from '../types/music';

interface SleepTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  sleepTimer: SleepTimerState;
  setSleepTimer: React.Dispatch<React.SetStateAction<SleepTimerState>>;
}

export const SleepTimerModal: React.FC<SleepTimerModalProps> = ({
  isOpen,
  onClose,
  sleepTimer,
  setSleepTimer,
}) => {
  if (!isOpen) return null;

  const timerOptions = [
    { label: 'Off', minutes: 0 },
    { label: '5 Minutes', minutes: 5 },
    { label: '15 Minutes', minutes: 15 },
    { label: '30 Minutes', minutes: 30 },
    { label: '45 Minutes', minutes: 45 },
    { label: '60 Minutes', minutes: 60 },
  ];

  const handleSelect = (minutes: number) => {
    if (minutes === 0) {
      audioEngine.clearSleepTimer();
      setSleepTimer({
        totalMinutes: 0,
        remainingSeconds: 0,
        isActive: false,
        targetTimestamp: null,
      });
    } else {
      setSleepTimer({
        totalMinutes: minutes,
        remainingSeconds: minutes * 60,
        isActive: true,
        targetTimestamp: Date.now() + minutes * 60 * 1000,
      });

      audioEngine.startSleepTimer(minutes, (remainingSec) => {
        setSleepTimer((prev) => ({
          ...prev,
          remainingSeconds: remainingSec,
          isActive: remainingSec > 0,
        }));
      });
    }
    onClose();
  };

  const formatCountdown = (totalSec: number) => {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-[#141414] border border-[#282828] p-6 shadow-2xl text-slate-100 flex flex-col gap-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#C6FF00]/10 border border-[#C6FF00]/30 flex items-center justify-center text-[#C6FF00]">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">Sleep Timer</h2>
              <p className="text-xs text-slate-400">Audio fades out gently</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-[#202020] transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Active Timer Display */}
        {sleepTimer.isActive && (
          <div className="bg-[#1A1A1A] border border-[#C6FF00]/40 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Clock className="w-5 h-5 text-[#C6FF00] animate-pulse" />
              <div>
                <span className="text-xs text-slate-400">Remaining</span>
                <p className="text-xl font-bold font-mono text-[#C6FF00] tabular-nums">
                  {formatCountdown(sleepTimer.remainingSeconds)}
                </p>
              </div>
            </div>
            <button
              onClick={() => handleSelect(0)}
              className="text-xs px-3 py-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 font-semibold transition"
            >
              Cancel Timer
            </button>
          </div>
        )}

        {/* Options List */}
        <div className="space-y-2">
          {timerOptions.map((opt) => {
            const isSelected =
              opt.minutes === 0
                ? !sleepTimer.isActive
                : sleepTimer.isActive && sleepTimer.totalMinutes === opt.minutes;

            return (
              <button
                key={opt.minutes}
                onClick={() => handleSelect(opt.minutes)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl border transition-all text-sm font-medium ${
                  isSelected
                    ? 'bg-[#C6FF00]/10 border-[#C6FF00] text-[#C6FF00]'
                    : 'bg-[#181818] border-[#262626] text-slate-200 hover:bg-[#202020] hover:text-white'
                }`}
              >
                <span>{opt.label}</span>
                {isSelected && <Check className="w-4 h-4 text-[#C6FF00]" />}
              </button>
            );
          })}
        </div>

        <p className="text-[11px] text-slate-400 text-center">
          Playback volume automatically lowers during the last 3 seconds before pausing.
        </p>
      </div>
    </div>
  );
};
