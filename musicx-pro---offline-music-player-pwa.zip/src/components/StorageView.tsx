import React, { useState } from 'react';
import {
  HardDrive,
  Trash2,
  AlertTriangle,
  FolderPlus,
  Music,
  CheckCircle2,
  Sparkles,
  Info,
} from 'lucide-react';
import { Song } from '../types/music';
import { PWAInstallButton } from './PWAInstallButton';

interface StorageViewProps {
  songs: Song[];
  playlistCount: number;
  totalBytes: number;
  onDeleteSong: (songId: string) => Promise<void>;
  onClearLibrary: () => Promise<void>;
  onAddFilesClick: () => void;
  onAddFolderClick: () => void;
}

export const StorageView: React.FC<StorageViewProps> = ({
  songs,
  playlistCount,
  totalBytes,
  onDeleteSong,
  onClearLibrary,
  onAddFilesClick,
  onAddFolderClick,
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [deletingSongId, setDeletingSongId] = useState<string | null>(null);

  const totalMb = (totalBytes / (1024 * 1024)).toFixed(2);

  const formatFileSize = (bytes: number) => {
    if (!bytes || bytes === 0) return '0 KB';
    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    return `${(kb / 1024).toFixed(2)} MB`;
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const handleConfirmClear = async () => {
    await onClearLibrary();
    setShowClearConfirm(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Settings & Storage
          </h1>
          <p className="text-xs text-slate-400">
            Offline IndexedDB allocation & hardware audio tuning
          </p>
        </div>

        <PWAInstallButton compact />
      </div>

      {/* Storage Summary Dashboard */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Storage Card */}
        <div className="p-5 rounded-3xl bg-[#161616] border border-[#252525] relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Offline Storage
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#C6FF00]/10 flex items-center justify-center text-[#C6FF00]">
              <HardDrive className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono tabular-nums tracking-tight">
            {totalMb} <span className="text-sm font-sans font-normal text-[#C6FF00]">MB</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Persisted securely in browser IndexedDB
          </p>
        </div>

        {/* Songs Count Card */}
        <div className="p-5 rounded-3xl bg-[#161616] border border-[#252525]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Total Songs
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#222] flex items-center justify-center text-slate-300">
              <Music className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono tabular-nums tracking-tight">
            {songs.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Audio tracks saved permanently offline
          </p>
        </div>

        {/* Playlists Count Card */}
        <div className="p-5 rounded-3xl bg-[#161616] border border-[#252525]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Custom Playlists
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#222] flex items-center justify-center text-slate-300">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono tabular-nums tracking-tight">
            {playlistCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            User-curated playlists & mixes
          </p>
        </div>
      </div>

      {/* Storage Management & Clear Library */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-5 rounded-3xl bg-[#161616] border border-[#252525]">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-white">Library Management</h3>
          <p className="text-xs text-slate-400">
            Import local folders or purge storage to free up space
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onAddFilesClick}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#222] hover:bg-[#2a2a2a] text-slate-200 hover:text-white transition text-xs font-semibold cursor-pointer"
          >
            <FolderPlus className="w-4 h-4 text-[#C6FF00]" />
            <span>+ Add Files</span>
          </button>
          <button
            onClick={onAddFolderClick}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#222] hover:bg-[#2a2a2a] text-slate-200 hover:text-white transition text-xs font-semibold cursor-pointer"
          >
            <FolderPlus className="w-4 h-4 text-[#C6FF00]" />
            <span>+ Add Folder</span>
          </button>
          <button
            onClick={() => setShowClearConfirm(true)}
            disabled={songs.length === 0}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-400 transition text-xs font-semibold disabled:opacity-40 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Library</span>
          </button>
        </div>
      </div>

      {/* Audio Engine & PWA Status Card */}
      <div className="p-5 rounded-3xl bg-[#141414] border border-[#222] space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
          <Info className="w-4 h-4 text-[#C6FF00]" />
          <span>System & Audio Engine Diagnostics</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#1A1A1A] border border-[#262626]">
            <span className="text-slate-400">Audio Processing</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Web Audio API Active
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#1A1A1A] border border-[#262626]">
            <span className="text-slate-400">Equalizer Hardware</span>
            <span className="font-semibold text-white">5-Band Biquad Filter</span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#1A1A1A] border border-[#262626]">
            <span className="text-slate-400">Offline Database</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> IndexedDB Persistent
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#1A1A1A] border border-[#262626]">
            <span className="text-slate-400">PWA Offline Caching</span>
            <span className="font-semibold text-[#C6FF00]">Service Worker Ready</span>
          </div>
        </div>
      </div>

      {/* Detailed Songs Storage Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Stored Audio Files</h2>
          <span className="text-xs text-slate-400">
            {songs.length} files ({totalMb} MB)
          </span>
        </div>

        {songs.length === 0 ? (
          <div className="p-8 rounded-3xl bg-[#141414] border border-[#222] text-center text-xs text-slate-400">
            No audio files currently stored in IndexedDB.
          </div>
        ) : (
          <div className="rounded-3xl bg-[#141414] border border-[#242424] overflow-hidden divide-y divide-[#222]">
            {songs.map((song) => (
              <div
                key={song.id}
                className="flex items-center justify-between p-3.5 hover:bg-[#1A1A1A] transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-[#282828]">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-white truncate">
                      {song.title}
                    </p>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                      <span className="truncate">{song.artist}</span>
                      <span>·</span>
                      <span className="uppercase text-[10px] px-1 py-0.2 bg-[#222] rounded text-slate-300">
                        {song.type.split('/')[1] || 'audio'}
                      </span>
                      <span>·</span>
                      <span>Added {formatDate(song.dateAdded)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-xs font-mono font-medium text-slate-300 tabular-nums">
                    {formatFileSize(song.size)}
                  </span>

                  <button
                    onClick={async () => {
                      if (window.confirm(`Delete "${song.title}" from offline storage?`)) {
                        setDeletingSongId(song.id);
                        await onDeleteSong(song.id);
                        setDeletingSongId(null);
                      }
                    }}
                    disabled={deletingSongId === song.id}
                    className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition cursor-pointer"
                    title="Delete Song"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Modal for Clear Library */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#141414] border border-[#282828] p-6 shadow-2xl text-slate-100 flex flex-col gap-4">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-base font-bold text-white">Clear entire library?</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                This will permanently delete all {songs.length} saved offline tracks and reset storage. This action cannot be undone.
              </p>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-[#222] text-xs font-semibold text-slate-300 hover:bg-[#282828]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmClear}
                className="flex-1 py-2.5 rounded-xl bg-red-500 text-xs font-bold text-white hover:bg-red-600 shadow-lg shadow-red-500/20"
              >
                Yes, Delete All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
