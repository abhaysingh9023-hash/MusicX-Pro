import { EqualizerPreset, EqualizerPresetName } from '../types/music';

export const EQ_FREQUENCIES = [60, 230, 910, 4000, 14000] as const;

export const EQ_PRESETS: Record<EqualizerPresetName, [number, number, number, number, number]> = {
  Flat: [0, 0, 0, 0, 0],
  'Bass Boost': [7, 5, 1, -1, -2],
  Electronic: [6, 3, 0, 3, 6],
  Rock: [5, 3, -1, 3, 5],
  'Vocal Boost': [-2, 1, 5, 4, 1],
  Acoustic: [3, 2, 2, 3, 3],
  'Hip-Hop': [8, 5, 0, 2, 4],
  Pop: [-1, 3, 5, 3, 0],
  Custom: [0, 0, 0, 0, 0],
};

class AudioEngine {
  private audio: HTMLAudioElement;
  private audioCtx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private filters: BiquadFilterNode[] = [];
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private isInitialized = false;
  private currentPreset: EqualizerPresetName = 'Flat';
  private currentGains: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  private frequencyDataBuffer: Uint8Array | null = null;

  // Sleep Timer
  private sleepTimerId: number | null = null;
  private sleepTimerTargetTime: number | null = null;
  private sleepTimerCallback: ((remainingSec: number) => void) | null = null;

  constructor() {
    this.audio = new Audio();
    this.audio.preload = 'auto';
    this.audio.crossOrigin = 'anonymous';
  }

  public getAudioElement(): HTMLAudioElement {
    return this.audio;
  }

  public initWebAudio() {
    if (this.isInitialized) return;

    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass();

      this.sourceNode = this.audioCtx.createMediaElementSource(this.audio);

      // Create 5-band equalizer filters
      this.filters = EQ_FREQUENCIES.map((freq, index) => {
        const filter = this.audioCtx!.createBiquadFilter();
        if (index === 0) {
          filter.type = 'lowshelf';
        } else if (index === EQ_FREQUENCIES.length - 1) {
          filter.type = 'highshelf';
        } else {
          filter.type = 'peaking';
          filter.Q.value = 1.0;
        }
        filter.frequency.value = freq;
        filter.gain.value = 0;
        return filter;
      });

      // Create AnalyserNode for visualizer
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 64; // 32 frequency bins
      this.analyser.smoothingTimeConstant = 0.82;
      this.frequencyDataBuffer = new Uint8Array(this.analyser.frequencyBinCount);

      // Create Master Gain Node
      this.gainNode = this.audioCtx.createGain();
      this.gainNode.gain.value = 1.0;

      // Connect graph: source -> filter0 -> ... -> filter4 -> analyser -> gainNode -> destination
      let lastNode: AudioNode = this.sourceNode;
      for (const filter of this.filters) {
        lastNode.connect(filter);
        lastNode = filter;
      }
      lastNode.connect(this.analyser);
      this.analyser.connect(this.gainNode);
      this.gainNode.connect(this.audioCtx.destination);

      this.isInitialized = true;
    } catch (e) {
      console.warn('Web Audio API not fully available or blocked by autoplay policy:', e);
    }
  }

  public ensureAudioContextRunning() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setSource(src: string) {
    this.audio.src = src;
    this.audio.load();
  }

  public async play(): Promise<void> {
    this.initWebAudio();
    this.ensureAudioContextRunning();
    return this.audio.play();
  }

  public pause(): void {
    this.audio.pause();
  }

  public seek(seconds: number): void {
    if (Number.isFinite(seconds)) {
      this.audio.currentTime = Math.max(0, Math.min(seconds, this.audio.duration || seconds));
    }
  }

  public skipSeconds(delta: number): void {
    const current = this.audio.currentTime || 0;
    this.seek(current + delta);
  }

  public setVolume(vol: number): void {
    const clamped = Math.max(0, Math.min(1, vol));
    this.audio.volume = clamped;
    if (this.gainNode) {
      this.gainNode.gain.value = clamped;
    }
  }

  public getVolume(): number {
    return this.audio.volume;
  }

  public getCurrentTime(): number {
    return this.audio.currentTime || 0;
  }

  public getDuration(): number {
    return this.audio.duration || 0;
  }

  public isPaused(): boolean {
    return this.audio.paused;
  }

  // Equalizer management
  public setEqualizerPreset(presetName: EqualizerPresetName) {
    this.currentPreset = presetName;
    const gains = EQ_PRESETS[presetName] || EQ_PRESETS.Flat;
    this.currentGains = [...gains];

    this.applyGains(this.currentGains);
  }

  public setBandGain(bandIndex: number, gainDb: number) {
    if (bandIndex < 0 || bandIndex >= this.filters.length) return;
    this.currentGains[bandIndex] = gainDb;
    this.currentPreset = 'Custom';

    if (this.filters[bandIndex]) {
      this.filters[bandIndex].gain.setTargetAtTime(gainDb, this.audioCtx?.currentTime || 0, 0.05);
    }
  }

  private applyGains(gains: [number, number, number, number, number]) {
    this.filters.forEach((filter, idx) => {
      const val = gains[idx] ?? 0;
      filter.gain.setTargetAtTime(val, this.audioCtx?.currentTime || 0, 0.05);
    });
  }

  public getEqualizerState(): { preset: EqualizerPresetName; gains: [number, number, number, number, number] } {
    return {
      preset: this.currentPreset,
      gains: [...this.currentGains],
    };
  }

  // Visualizer frequency data
  public getFrequencyData(): Uint8Array {
    if (!this.analyser || !this.frequencyDataBuffer) {
      return new Uint8Array(32).fill(0);
    }
    (this.analyser as unknown as { getByteFrequencyData: (arr: Uint8Array) => void }).getByteFrequencyData(this.frequencyDataBuffer);
    return this.frequencyDataBuffer;
  }

  // Sleep Timer
  public startSleepTimer(minutes: number, onTick: (remainingSeconds: number) => void) {
    this.clearSleepTimer();
    if (minutes <= 0) return;

    this.sleepTimerCallback = onTick;
    this.sleepTimerTargetTime = Date.now() + minutes * 60 * 1000;

    // Immediately trigger initial callback
    onTick(minutes * 60);

    this.sleepTimerId = window.setInterval(() => {
      if (!this.sleepTimerTargetTime) return;
      const remainingMs = this.sleepTimerTargetTime - Date.now();
      const remainingSec = Math.max(0, Math.ceil(remainingMs / 1000));

      if (this.sleepTimerCallback) {
        this.sleepTimerCallback(remainingSec);
      }

      if (remainingSec <= 0) {
        this.executeSleepTimerExpiry();
      }
    }, 1000);
  }

  public clearSleepTimer() {
    if (this.sleepTimerId !== null) {
      clearInterval(this.sleepTimerId);
      this.sleepTimerId = null;
    }
    this.sleepTimerTargetTime = null;
    this.sleepTimerCallback = null;
  }

  private executeSleepTimerExpiry() {
    this.clearSleepTimer();

    // Smooth 2-second volume fade out
    const startVolume = this.audio.volume;
    const fadeSteps = 20;
    let step = 0;

    const fadeInterval = setInterval(() => {
      step++;
      const factor = Math.max(0, 1 - step / fadeSteps);
      this.audio.volume = startVolume * factor;

      if (step >= fadeSteps) {
        clearInterval(fadeInterval);
        this.audio.pause();
        this.audio.volume = startVolume; // restore original volume for next time
      }
    }, 100);
  }
}

export const audioEngine = new AudioEngine();
