import { Song, Playlist } from '../types/music';
import { createSynthWavBlob } from '../utils/audioSynth';

const DB_NAME = 'MusicXProDB';
const DB_VERSION = 1;

export interface DBStoredSong extends Omit<Song, 'audioBlob'> {
  audioBlob: Blob;
}

let dbPromise: Promise<IDBDatabase> | null = null;

export function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // Song Object Store
      if (!db.objectStoreNames.contains('songs')) {
        const songStore = db.createObjectStore('songs', { keyPath: 'id' });
        songStore.createIndex('title', 'title', { unique: false });
        songStore.createIndex('artist', 'artist', { unique: false });
        songStore.createIndex('dateAdded', 'dateAdded', { unique: false });
        songStore.createIndex('isFavorite', 'isFavorite', { unique: false });
      }

      // Playlists Object Store
      if (!db.objectStoreNames.contains('playlists')) {
        db.createObjectStore('playlists', { keyPath: 'id' });
      }

      // Settings Object Store
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };

    request.onsuccess = (event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };

    request.onerror = (event) => {
      reject((event.target as IDBOpenDBRequest).error);
    };
  });

  return dbPromise;
}

// In-memory cache for Object URLs to prevent memory leaks and redundant URLs
const blobUrlMap = new Map<string, string>();

export function getAudioObjectUrl(songId: string, blob: Blob): string {
  if (blobUrlMap.has(songId)) {
    return blobUrlMap.get(songId)!;
  }
  const url = URL.createObjectURL(blob);
  blobUrlMap.set(songId, url);
  return url;
}

export function revokeAudioObjectUrl(songId: string) {
  const url = blobUrlMap.get(songId);
  if (url) {
    URL.revokeObjectURL(url);
    blobUrlMap.delete(songId);
  }
}

/**
 * Seed initial high-fidelity offline tracks if library is empty
 */
export async function seedInitialLibraryIfEmpty(): Promise<void> {
  const db = await getDB();
  const tx = db.transaction('songs', 'readonly');
  const store = tx.objectStore('songs');
  const countRequest = store.count();

  const count = await new Promise<number>((resolve, reject) => {
    countRequest.onsuccess = () => resolve(countRequest.result);
    countRequest.onerror = () => reject(countRequest.error);
  });

  if (count > 0) return;

  // Generate demo offline tracks
  const demoDefinitions = [
    {
      id: 'demo-neon-pulse',
      title: 'Neon Pulse',
      artist: 'Cybernate',
      album: 'Neon Pulse',
      genre: 'Synthwave',
      coverUrl: '/src/assets/images/album_neon_cyberpunk_1794425656462.jpg',
      synthType: 'synthwave' as const,
      duration: 32,
    },
    {
      id: 'demo-midnight-echoes',
      title: 'Voltaic Fluence',
      artist: 'Voltaic Audio',
      album: 'Midnight Echoes',
      genre: 'Electronic',
      coverUrl: '/src/assets/images/album_midnight_echoes_1794425658272.jpg',
      synthType: 'future' as const,
      duration: 32,
    },
    {
      id: 'demo-synthetic-void',
      title: 'Synthetic Void',
      artist: 'Aether Drives',
      album: 'Synth Pulse',
      genre: 'Cyber Beats',
      coverUrl: '/src/assets/images/album_synth_pulse_1794425657767.jpg',
      synthType: 'ambient' as const,
      duration: 32,
    },
    {
      id: 'demo-cosmic-chill',
      title: 'Deep Space Chill',
      artist: 'Lumina Cosma',
      album: 'Cosmic Chill',
      genre: 'Space Ambient',
      coverUrl: '/src/assets/images/album_cosmic_chill_1794425657063.jpg',
      synthType: 'chill' as const,
      duration: 32,
    },
  ];

  const now = Date.now();
  const songIds: string[] = [];

  for (let i = 0; i < demoDefinitions.length; i++) {
    const d = demoDefinitions[i];
    const blob = createSynthWavBlob(d.synthType, d.duration);
    const storedSong: DBStoredSong = {
      id: d.id,
      title: d.title,
      artist: d.artist,
      album: d.album,
      duration: d.duration,
      size: blob.size,
      type: 'audio/wav',
      coverUrl: d.coverUrl,
      audioBlob: blob,
      dateAdded: now - i * 60000,
      isFavorite: i === 0 || i === 2, // 2 pre-favorited
      isDemo: true,
    };

    await saveSongToDB(storedSong);
    songIds.push(d.id);
  }

  // Create default starter playlist
  const defaultPlaylist: Playlist = {
    id: 'starter-playlist',
    name: 'Neon Cyber Highlights',
    songIds: songIds.slice(0, 3),
    dateCreated: Date.now(),
    coverUrl: '/src/assets/images/album_neon_cyberpunk_1794425656462.jpg',
  };
  await savePlaylistToDB(defaultPlaylist);
}

export async function saveSongToDB(song: DBStoredSong): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('songs', 'readwrite');
    const store = tx.objectStore('songs');
    const req = store.put(song);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getAllSongs(): Promise<Song[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('songs', 'readonly');
    const store = tx.objectStore('songs');
    const req = store.getAll();

    req.onsuccess = () => {
      const records = req.result as DBStoredSong[];
      // Strip audioBlob from the lightweight list to avoid holding multiple heavy blobs in memory
      // but retain size and metadata
      const songs: Song[] = records.map((r) => ({
        id: r.id,
        title: r.title,
        artist: r.artist,
        album: r.album,
        duration: r.duration,
        size: r.size,
        type: r.type,
        coverUrl: r.coverUrl,
        dateAdded: r.dateAdded,
        isFavorite: r.isFavorite,
        isDemo: r.isDemo,
      }));
      resolve(songs);
    };

    req.onerror = () => reject(req.error);
  });
}

export async function getSongAudioBlob(songId: string): Promise<Blob | null> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('songs', 'readonly');
    const store = tx.objectStore('songs');
    const req = store.get(songId);

    req.onsuccess = () => {
      const record = req.result as DBStoredSong | undefined;
      resolve(record ? record.audioBlob : null);
    };

    req.onerror = () => reject(req.error);
  });
}

export async function toggleSongFavoriteInDB(songId: string): Promise<boolean> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('songs', 'readwrite');
    const store = tx.objectStore('songs');
    const req = store.get(songId);

    req.onsuccess = () => {
      const record = req.result as DBStoredSong | undefined;
      if (!record) {
        reject(new Error('Song not found'));
        return;
      }
      record.isFavorite = !record.isFavorite;
      const updateReq = store.put(record);
      updateReq.onsuccess = () => resolve(record.isFavorite);
      updateReq.onerror = () => reject(updateReq.error);
    };

    req.onerror = () => reject(req.error);
  });
}

export async function deleteSongFromDB(songId: string): Promise<void> {
  revokeAudioObjectUrl(songId);
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['songs', 'playlists'], 'readwrite');
    const songStore = tx.objectStore('songs');
    const playlistStore = tx.objectStore('playlists');

    songStore.delete(songId);

    // Also remove from all playlists
    const plReq = playlistStore.getAll();
    plReq.onsuccess = () => {
      const playlists = plReq.result as Playlist[];
      for (const pl of playlists) {
        if (pl.songIds.includes(songId)) {
          pl.songIds = pl.songIds.filter((id) => id !== songId);
          playlistStore.put(pl);
        }
      }
      resolve();
    };

    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllSongsFromDB(): Promise<void> {
  blobUrlMap.forEach((url) => URL.revokeObjectURL(url));
  blobUrlMap.clear();

  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['songs', 'playlists'], 'readwrite');
    tx.objectStore('songs').clear();
    
    // Clear playlist song associations
    const plStore = tx.objectStore('playlists');
    const plReq = plStore.getAll();
    plReq.onsuccess = () => {
      const playlists = plReq.result as Playlist[];
      for (const pl of playlists) {
        pl.songIds = [];
        plStore.put(pl);
      }
      resolve();
    };

    tx.onerror = () => reject(tx.error);
  });
}

export async function getStorageStats(): Promise<{ totalBytes: number; songCount: number; playlistCount: number }> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['songs', 'playlists'], 'readonly');
    const songStore = tx.objectStore('songs');
    const playlistStore = tx.objectStore('playlists');

    const songReq = songStore.getAll();
    const plReq = playlistStore.count();

    songReq.onsuccess = () => {
      const songs = songReq.result as DBStoredSong[];
      const totalBytes = songs.reduce((acc, s) => acc + (s.size || 0), 0);
      plReq.onsuccess = () => {
        resolve({
          totalBytes,
          songCount: songs.length,
          playlistCount: plReq.result,
        });
      };
    };

    tx.onerror = () => reject(tx.error);
  });
}

// Playlists API
export async function getAllPlaylists(): Promise<Playlist[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('playlists', 'readonly');
    const store = tx.objectStore('playlists');
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as Playlist[]);
    req.onerror = () => reject(req.error);
  });
}

export async function savePlaylistToDB(playlist: Playlist): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('playlists', 'readwrite');
    const store = tx.objectStore('playlists');
    const req = store.put(playlist);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deletePlaylistFromDB(playlistId: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('playlists', 'readwrite');
    const store = tx.objectStore('playlists');
    const req = store.delete(playlistId);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function renamePlaylistInDB(playlistId: string, newName: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('playlists', 'readwrite');
    const store = tx.objectStore('playlists');
    const req = store.get(playlistId);

    req.onsuccess = () => {
      const pl = req.result as Playlist | undefined;
      if (!pl) {
        reject(new Error('Playlist not found'));
        return;
      }
      pl.name = newName.trim();
      const updateReq = store.put(pl);
      updateReq.onsuccess = () => resolve();
      updateReq.onerror = () => reject(updateReq.error);
    };

    req.onerror = () => reject(req.error);
  });
}

export async function addSongToPlaylistInDB(playlistId: string, songId: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('playlists', 'readwrite');
    const store = tx.objectStore('playlists');
    const req = store.get(playlistId);

    req.onsuccess = () => {
      const pl = req.result as Playlist | undefined;
      if (!pl) {
        reject(new Error('Playlist not found'));
        return;
      }
      if (!pl.songIds.includes(songId)) {
        pl.songIds.push(songId);
      }
      const updateReq = store.put(pl);
      updateReq.onsuccess = () => resolve();
      updateReq.onerror = () => reject(updateReq.error);
    };

    req.onerror = () => reject(req.error);
  });
}

export async function removeSongFromPlaylistInDB(playlistId: string, songId: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('playlists', 'readwrite');
    const store = tx.objectStore('playlists');
    const req = store.get(playlistId);

    req.onsuccess = () => {
      const pl = req.result as Playlist | undefined;
      if (!pl) {
        reject(new Error('Playlist not found'));
        return;
      }
      pl.songIds = pl.songIds.filter((id) => id !== songId);
      const updateReq = store.put(pl);
      updateReq.onsuccess = () => resolve();
      updateReq.onerror = () => reject(updateReq.error);
    };

    req.onerror = () => reject(req.error);
  });
}
