export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  size: number; // in bytes
  type: string; // mime type e.g. 'audio/mpeg'
  coverUrl: string; // image path or data URL
  audioBlob?: Blob; // optional in memory if loaded or converted to Object URL
  dateAdded: number; // timestamp
  isFavorite: boolean;
  isDemo?: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  songIds: string[];
  dateCreated: number;
  coverUrl?: string;
}

export type RepeatMode = 'off' | 'all' | 'one';

export type EqualizerPresetName =
  | 'Flat'
  | 'Bass Boost'
  | 'Electronic'
  | 'Rock'
  | 'Vocal Boost'
  | 'Acoustic'
  | 'Hip-Hop'
  | 'Pop'
  | 'Custom';

export interface EqualizerPreset {
  name: EqualizerPresetName;
  gains: [number, number, number, number, number]; // 60Hz, 230Hz, 910Hz, 4kHz, 14kHz
}

export type SortOption = 'recent' | 'title-asc' | 'title-desc' | 'artist-asc' | 'duration-desc';

export interface SleepTimerState {
  totalMinutes: number;
  remainingSeconds: number;
  isActive: boolean;
  targetTimestamp: number | null;
}
