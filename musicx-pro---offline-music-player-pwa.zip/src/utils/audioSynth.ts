/**
 * Generates an in-memory 16-bit 44.1kHz Stereo WAV Blob with harmonic chords & arpeggios
 * so the player has immediate real offline music out of the box!
 */
export function createSynthWavBlob(
  type: 'synthwave' | 'ambient' | 'future' | 'chill',
  durationSeconds: number = 32
): Blob {
  const sampleRate = 44100;
  const numChannels = 2;
  const totalSamples = Math.floor(sampleRate * durationSeconds);
  const bytesPerSample = 2; // 16-bit PCM
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = totalSamples * blockAlign;
  const bufferSize = 44 + dataSize;

  const buffer = new ArrayBuffer(bufferSize);
  const view = new DataView(buffer);

  // Helper to write ASCII string
  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  // RIFF Chunk Descriptor
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');

  // "fmt " sub-chunk
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 = PCM)
  view.setUint16(22, numChannels, true); // NumChannels
  view.setUint32(24, sampleRate, true); // SampleRate
  view.setUint32(28, byteRate, true); // ByteRate
  view.setUint16(32, blockAlign, true); // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample

  // "data" sub-chunk
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  // Audio synthesis notes & frequencies
  // Musical chords in Hz:
  // Am: A2 (110), C3 (130.8), E3 (164.8), A3 (220)
  // F: F2 (87.3), C3 (130.8), F3 (174.6), A3 (220)
  // C: C2 (65.4), G2 (98.0), E3 (164.8), G3 (196.0)
  // G: G2 (98.0), D3 (146.8), B3 (246.9), D4 (293.7)
  const progressions: Record<string, number[][]> = {
    synthwave: [
      [110, 220, 329.6, 440], // Am
      [87.3, 174.6, 261.6, 349.2], // F
      [65.4, 130.8, 196.0, 261.6], // C
      [98.0, 196.0, 293.7, 392.0], // G
    ],
    ambient: [
      [130.8, 196.0, 261.6, 392.0], // Cmaj9
      [110.0, 164.8, 220.0, 329.6], // Am7
      [87.3, 130.8, 174.6, 261.6], // Fmaj7
      [146.8, 220.0, 293.7, 440.0], // Dm7
    ],
    future: [
      [146.8, 220.0, 293.7, 349.2], // Dm
      [174.6, 261.6, 349.2, 440.0], // F
      [196.0, 293.7, 392.0, 493.9], // G
      [110.0, 164.8, 220.0, 261.6], // Am
    ],
    chill: [
      [130.8, 164.8, 196.0, 246.9], // Cmaj7
      [110.0, 130.8, 164.8, 196.0], // Am7
      [87.3, 110.0, 130.8, 174.6], // Fmaj7
      [98.0, 123.5, 146.8, 196.0], // G7
    ],
  };

  const chordSeq = progressions[type] || progressions.synthwave;
  const chordDuration = 4.0; // 4 seconds per chord

  let offset = 44;
  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    const chordIndex = Math.floor(t / chordDuration) % chordSeq.length;
    const currentChord = chordSeq[chordIndex];
    const chordTime = t % chordDuration;

    // Bassline (fundamental)
    const bassFreq = currentChord[0];
    const bass = Math.sin(2 * Math.PI * bassFreq * t) * 0.35 +
                 Math.sin(2 * Math.PI * (bassFreq * 0.5) * t) * 0.2;

    // Arpeggiator (16th notes: 4 notes per second)
    const arpSpeed = type === 'ambient' ? 2 : 4;
    const arpIndex = Math.floor(t * arpSpeed) % currentChord.length;
    const arpFreq = currentChord[arpIndex] * (type === 'chill' ? 1.5 : 2.0);
    const arpTime = (t * arpSpeed) % 1;
    const arpEnv = Math.exp(-arpTime * 3.5); // decay envelope
    const arp = Math.sin(2 * Math.PI * arpFreq * t) * arpEnv * 0.25;

    // Pad chords (soft harmonic overtone)
    let pad = 0;
    for (let c = 0; c < currentChord.length; c++) {
      pad += Math.sin(2 * Math.PI * currentChord[c] * t) * 0.08;
      // Detuned chorus
      pad += Math.sin(2 * Math.PI * (currentChord[c] * 1.003) * t) * 0.05;
    }

    // Drum beat: kick on beat 1 & 3, subtle snare/hat on 2 & 4 (except for ambient)
    let drums = 0;
    if (type !== 'ambient') {
      const beat = (t * 2) % 2; // 120 bpm (2 beats per sec)
      const beatNum = Math.floor(t * 2) % 4;

      if (beatNum === 0 || beatNum === 2) {
        // Kick drum (pitch drop)
        const kickTime = beat % 1;
        if (kickTime < 0.25) {
          const kickFreq = Math.max(40, 150 * Math.exp(-kickTime * 20));
          drums += Math.sin(2 * Math.PI * kickFreq * kickTime) * Math.exp(-kickTime * 12) * 0.45;
        }
      }

      // Hi-hat tick
      const hatBeat = (t * 4) % 1;
      if (hatBeat < 0.05) {
        // Pseudo white noise
        const noise = (Math.random() * 2 - 1) * 0.12 * Math.exp(-hatBeat * 40);
        drums += noise;
      }
    }

    // Master envelope for fade in/out at ends of loop
    let masterEnv = 1.0;
    if (t < 0.5) masterEnv = t / 0.5;
    else if (t > durationSeconds - 0.5) masterEnv = (durationSeconds - t) / 0.5;

    // Mixdown with subtle stereo panning
    const leftMix = (bass + arp * 0.7 + pad * 0.8 + drums) * masterEnv * 0.8;
    const rightMix = (bass + arp * 1.1 + pad * 0.9 + drums) * masterEnv * 0.8;

    // Clamp to 16-bit integer range [-32768, 32767]
    const leftSample = Math.max(-32767, Math.min(32767, Math.floor(leftMix * 32767)));
    const rightSample = Math.max(-32767, Math.min(32767, Math.floor(rightMix * 32767)));

    view.setInt16(offset, leftSample, true);
    view.setInt16(offset + 2, rightSample, true);
    offset += 4;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}
