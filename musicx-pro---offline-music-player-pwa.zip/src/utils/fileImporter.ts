import { DBStoredSong, saveSongToDB } from '../services/db';

/**
 * Extracts basic metadata and duration from an audio file and saves it to IndexedDB
 */
export async function importAudioFiles(files: FileList | File[]): Promise<DBStoredSong[]> {
  const fileArray = Array.from(files).filter((file) => {
    // accept audio mime types or extensions
    const ext = file.name.split('.').pop()?.toLowerCase();
    return file.type.startsWith('audio/') || ['mp3', 'wav', 'aac', 'm4a', 'flac', 'ogg'].includes(ext || '');
  });

  if (fileArray.length === 0) {
    return [];
  }

  const results: DBStoredSong[] = [];
  const now = Date.now();

  for (let i = 0; i < fileArray.length; i++) {
    const file = fileArray[i];
    try {
      const song = await parseAudioFile(file, now - i * 100);
      await saveSongToDB(song);
      results.push(song);
    } catch (e) {
      console.error(`Error importing file ${file.name}:`, e);
    }
  }

  return results;
}

async function parseAudioFile(file: File, timestamp: number): Promise<DBStoredSong> {
  const cleanName = file.name.replace(/\.[^/.]+$/, '');
  let title = cleanName;
  let artist = 'Local Artist';
  let album = 'Offline Music';

  // Check common naming patterns like "Artist - Title"
  if (cleanName.includes(' - ')) {
    const parts = cleanName.split(' - ');
    artist = parts[0].trim();
    title = parts.slice(1).join(' - ').trim();
  }

  // Create temporary blob URL to determine audio duration
  const tempUrl = URL.createObjectURL(file);
  let duration = 180; // fallback 3 minutes

  try {
    duration = await new Promise<number>((resolve) => {
      const audio = new Audio();
      audio.preload = 'metadata';
      audio.src = tempUrl;

      const onLoaded = () => {
        cleanup();
        resolve(Math.round(audio.duration) || 180);
      };

      const onError = () => {
        cleanup();
        resolve(180);
      };

      const cleanup = () => {
        audio.removeEventListener('loadedmetadata', onLoaded);
        audio.removeEventListener('error', onError);
      };

      audio.addEventListener('loadedmetadata', onLoaded);
      audio.addEventListener('error', onError);

      // 5-second timeout in case browser hangs on corrupt audio
      setTimeout(() => {
        cleanup();
        resolve(180);
      }, 5000);
    });
  } finally {
    URL.revokeObjectURL(tempUrl);
  }

  // Try extracting embedded ID3 cover art or generate custom themed SVG art
  let coverUrl = await extractID3CoverArt(file);
  if (!coverUrl) {
    coverUrl = createCoverArtDataUrl(title, artist);
  }

  const uniqueId = `local-${timestamp}-${Math.random().toString(36).substring(2, 9)}`;

  return {
    id: uniqueId,
    title,
    artist,
    album,
    duration,
    size: file.size,
    type: file.type || 'audio/mpeg',
    coverUrl,
    audioBlob: file,
    dateAdded: timestamp,
    isFavorite: false,
    isDemo: false,
  };
}

/**
 * Attempts to parse ID3v2 APIC frame for cover image
 */
async function extractID3CoverArt(file: File): Promise<string | null> {
  try {
    // Only inspect first 512KB for speed
    const slice = file.slice(0, Math.min(524288, file.size));
    const arrayBuffer = await slice.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);

    // Check ID3 header 'ID3'
    if (bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33) {
      // Search for 'APIC'
      for (let i = 10; i < bytes.length - 10; i++) {
        if (
          bytes[i] === 0x41 && // 'A'
          bytes[i + 1] === 0x50 && // 'P'
          bytes[i + 2] === 0x49 && // 'I'
          bytes[i + 3] === 0x43 // 'C'
        ) {
          // Read frame size
          const frameSize =
            (bytes[i + 4] << 24) |
            (bytes[i + 5] << 16) |
            (bytes[i + 6] << 8) |
            bytes[i + 7];

          if (frameSize > 0 && i + 10 + frameSize <= bytes.length) {
            const frameBytes = bytes.slice(i + 10, i + 10 + frameSize);
            // Search for image/jpeg (0xFF 0xD8) or image/png (0x89 0x50 0x4E 0x47)
            for (let j = 0; j < frameBytes.length - 4; j++) {
              if (frameBytes[j] === 0xff && frameBytes[j + 1] === 0xd8) {
                const imgBlob = new Blob([frameBytes.slice(j)], { type: 'image/jpeg' });
                return URL.createObjectURL(imgBlob);
              }
              if (
                frameBytes[j] === 0x89 &&
                frameBytes[j + 1] === 0x50 &&
                frameBytes[j + 2] === 0x4e &&
                frameBytes[j + 3] === 0x47
              ) {
                const imgBlob = new Blob([frameBytes.slice(j)], { type: 'image/png' });
                return URL.createObjectURL(imgBlob);
              }
            }
          }
        }
      }
    }
  } catch (e) {
    // Graceful fallback to SVG generator
  }
  return null;
}

/**
 * Generates an SVG Data URL cover art in the app's sleek neon lime & dark charcoal style
 */
function createCoverArtDataUrl(title: string, artist: string): string {
  const hash = (title + artist).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const hue = 75 + (hash % 20); // neon lime variations
  const initial = (title.trim()[0] || 'M').toUpperCase();

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300">
    <rect width="300" height="300" fill="#141414"/>
    <circle cx="150" cy="150" r="130" fill="#181818" stroke="#252525" stroke-width="2"/>
    <circle cx="150" cy="150" r="90" fill="none" stroke="#2a2a2a" stroke-width="1.5"/>
    <circle cx="150" cy="150" r="60" fill="#0F0F0F" stroke="hsl(${hue}, 100%, 50%)" stroke-width="3"/>
    <text x="150" y="162" font-family="sans-serif" font-weight="bold" font-size="38" fill="hsl(${hue}, 100%, 50%)" text-anchor="middle">${initial}</text>
    <rect x="70" y="240" width="160" height="4" rx="2" fill="hsl(${hue}, 100%, 50%)" opacity="0.8"/>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
